/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { generateOverworld, generateCaves } from './utils/worldGenerator';
import { Tile, PlayerStats, NPC, Quest, InventoryItem, Monster } from './types';
import { GameCanvas } from './components/GameCanvas';
import { GameUI } from './components/GameUI';
import { PlayerCustomizer } from './components/PlayerCustomizer';
import { VivobookNotepad } from './components/VivobookNotepad';
import { Gamepad, User, HelpCircle, FileText, Compass, Sparkles } from 'lucide-react';

export default function App() {
  // Initialize World generation data maps
  const [worldMaps, setWorldMaps] = useState<{
    overworldTiles: Tile[][];
    overworldNPCs: NPC[];
    overworldMonsters: Monster[];
    caveTiles: Tile[][];
    caveMonsters: Monster[];
    caveSpawnPosition?: { x: number; y: number };
  } | null>(null);

  // Active world tracker
  const [currentWorld, setCurrentWorld] = useState<'overworld' | 'cave'>('overworld');

  // Player core stats
  const [playerStats, setPlayerStats] = useState<PlayerStats>({
    hp: 100,
    maxHp: 100,
    mp: 50,
    maxMp: 50,
    level: 1,
    xp: 0,
    maxXp: 100,
    gold: 35,
    attack: 12,
    speed: 4,
  });

  // Backpack Inventory
  const [inventory, setInventory] = useState<InventoryItem[]>([
    {
      id: 'potion_heal',
      name: 'Restorative Red Potion (+30 HP)',
      type: 'potion',
      description: 'A glowing thick red infusion that heals wounds immediately.',
      quantity: 2,
      color: '#f43f5e',
    },
  ]);

  // Quests Checklist
  const [quests, setQuests] = useState<Quest[]>([]);

  // Active Dialogue State
  const [activeNPC, setActiveNPC] = useState<NPC | null>(null);
  const [dialogNode, setDialogNode] = useState<any | null>(null);

  // Player Visuals customizers
  const [playerAvatar, setPlayerAvatar] = useState<string>('knight');
  const [avatarColor, setAvatarColor] = useState<string>('#0ea5e9');

  // Live Toast messages feed
  const [toastMessage, setToastMessage] = useState<{ text: string; type: string } | null>({
    text: '🌲 Welcome to Meadowvale open world! Move with WASD / Keys & hit SPACE to swing sword.',
    type: 'info',
  });

  // active visual sidebar panel on desktop tabs layout
  const [activeTab, setActiveTab] = useState<'game' | 'avatar' | 'notepad' | 'controls'>('game');

  // Active pet companion state
  const [activePet, setActivePet] = useState<'none' | 'corgi' | 'dragon' | 'slime' | 'wolf'>('none');

  // Seed maps on mount
  useEffect(() => {
    const overworld = generateOverworld();
    const cave = generateCaves();
    setWorldMaps({
      overworldTiles: overworld.tiles,
      overworldNPCs: overworld.npcs,
      overworldMonsters: overworld.monsters,
      caveTiles: cave.tiles,
      caveMonsters: cave.monsters,
      caveSpawnPosition: cave.spawnPosition,
    });
  }, []);

  const triggerToast = (text: string, type: 'info' | 'loot' | 'combat' | 'danger' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 5000);
  };

  if (!worldMaps) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <Sparkles className="w-10 h-10 text-indigo-400 animate-spin mb-3" />
        <div className="font-mono text-xs">Casting procedural code structures... Please hold</div>
      </div>
    );
  }

  // Active scene objects based on map layer
  const currentTiles = currentWorld === 'overworld' ? worldMaps.overworldTiles : worldMaps.caveTiles;
  const currentNPCs = currentWorld === 'overworld' ? worldMaps.overworldNPCs : [];
  const currentMonsters = currentWorld === 'overworld' ? worldMaps.overworldMonsters : worldMaps.caveMonsters;

  // Drink restorative item from inventory
  const handleDrinkPotion = (itemId: string) => {
    const itemIdx = inventory.findIndex((it) => it.id === itemId);
    if (itemIdx === -1) return;

    const item = inventory[itemIdx];
    if (item.quantity <= 0) return;

    // Apply HP recovery
    let hpBoost = 30;
    const updatedHp = Math.min(playerStats.maxHp, playerStats.hp + hpBoost);
    setPlayerStats((prev) => ({ ...prev, hp: updatedHp }));

    // Decrement item count
    const updatedInv = [...inventory];
    if (item.quantity === 1) {
      updatedInv.splice(itemIdx, 1);
    } else {
      updatedInv[itemIdx] = { ...item, quantity: item.quantity - 1 };
    }
    setInventory(updatedInv);
    triggerToast(`🧪 Drank ${item.name}! Restored +30 HP immediately.`, 'info');
  };

  // Slayed enemy objective increments
  const handleMonsterSlay = (monsterType: string) => {
    // Slay monsters in maps logic
    if (currentWorld === 'overworld') {
      const remainingMonsters = worldMaps.overworldMonsters.filter((m) => m.hp > 0);
      setWorldMaps((prev) => prev ? { ...prev, overworldMonsters: remainingMonsters } : null);
    } else {
      const remainingMonsters = worldMaps.caveMonsters.filter((m) => m.hp > 0);
      setWorldMaps((prev) => prev ? { ...prev, caveMonsters: remainingMonsters } : null);
    }

    // Process quest progression
    setQuests((prevQuests) => {
      let questUpdate = false;
      const updated = prevQuests.map((q) => {
        if (q.status === 'active' && q.targetId === monsterType) {
          const nextCount = q.currentCount + 1;
          const finished = nextCount >= q.requiredCount;
          questUpdate = true;
          return {
            ...q,
            currentCount: nextCount,
            status: (finished ? 'completed' : 'active') as any,
          };
        }
        return q;
      });

      if (questUpdate) {
        // Find if we just finished some quest to update Aaron dialog node dynamic response!
        const hasJustFinished = updated.some(
          (q) => q.status === 'completed' && quests.find((y) => y.id === q.id)?.status === 'active'
        );
        if (hasJustFinished) {
          triggerToast('📜 Quest Objective Fulfilled! Return to Elder Aaron in the village.', 'info');
        }
      }
      return updated;
    });
  };

  // Speak dialogue events handler
  const handleSpeakDialogue = (npc: NPC) => {
    setActiveNPC(npc);

    // Dynamic dialogue selection based on quests status
    const matchingSlimeQuest = quests.find((q) => q.id === 'quest_slime');
    const matchingGoblinQuest = quests.find((q) => q.id === 'quest_goblin');

    if (npc.id === 'elder') {
      if (matchingSlimeQuest?.status === 'completed' || matchingGoblinQuest?.status === 'completed') {
        const node = npc.dialogue.find((node) => node.id === 'complete_quest');
        setDialogNode(node || npc.dialogue[0]);
      } else if (matchingSlimeQuest?.status === 'active' || matchingGoblinQuest?.status === 'active') {
        const node = npc.dialogue.find((node) => node.id === 'active_quest');
        setDialogNode(node || npc.dialogue[0]);
      } else {
        const node = npc.dialogue.find((node) => node.id === 'start');
        setDialogNode(node || npc.dialogue[0]);
      }
    } else {
      // Lily or Explorer
      const node = npc.dialogue.find((node) => node.id === 'start');
      setDialogNode(node || npc.dialogue[0]);
    }
  };

  // Branching dialog choices router
  const handleSelectDialogueOption = (action?: string, nextId?: string) => {
    if (!activeNPC) return;

    if (nextId) {
      const node = activeNPC.dialogue.find((n) => n.id === nextId);
      setDialogNode(node || null);
      return;
    }

    if (action) {
      // 1. Quests Actions
      if (action === 'accept_slime_quest') {
        const newQuest: Quest = {
          id: 'quest_slime',
          title: 'Forest Slime Cleanse',
          description: 'Slay 4 bouncy Slimes gathered in the dense forests of Meadowvale.',
          status: 'active',
          type: 'kill',
          targetId: 'slime',
          requiredCount: 4,
          currentCount: 0,
          xpReward: 60,
          goldReward: 40,
        };
        setQuests((prev) => [...prev, newQuest]);
        triggerToast('📜 Accepted Elder Aaron\'s Quest: Slay 4 Slimes!', 'info');
        setActiveNPC(null);
        return;
      }

      if (action === 'accept_goblin_quest') {
        const newQuest: Quest = {
          id: 'quest_goblin',
          title: 'Deep Cave Goblin Raid',
          description: 'Descend to the subterranean caves to clear out a dangerous Cave Goblin.',
          status: 'active',
          type: 'kill',
          targetId: 'goblin',
          requiredCount: 1,
          currentCount: 0,
          xpReward: 90,
          goldReward: 60,
        };
        setQuests((prev) => [...prev, newQuest]);
        triggerToast('📜 Accepted Quest: Descend to the Caves and defeat a Goblin!', 'info');
        setActiveNPC(null);
        return;
      }

      if (action === 'complete_quest_reward') {
        // Verify which quest is completed
        const slimeQ = quests.find((q) => q.id === 'quest_slime' && q.status === 'completed');
        const goblinQ = quests.find((q) => q.id === 'quest_goblin' && q.status === 'completed');

        const activeQ = slimeQ || goblinQ;
        if (activeQ) {
          const goldBonus = activeQ.goldReward;
          const xpBonus = activeQ.xpReward;

          let nextXp = playerStats.xp + xpBonus;
          let levelUp = false;
          let currLevel = playerStats.level;
          let currMaxXp = playerStats.maxXp;
          let currHp = playerStats.hp;
          let currMaxHp = playerStats.maxHp;

          if (nextXp >= currMaxXp) {
            levelUp = true;
            currLevel += 1;
            nextXp = 0;
            currMaxXp = Math.floor(currMaxXp * 1.5);
            currMaxHp += 20;
            currHp = currMaxHp;
          }

          setPlayerStats((prev) => ({
            ...prev,
            gold: prev.gold + goldBonus,
            xp: nextXp,
            level: currLevel,
            maxXp: currMaxXp,
            hp: currHp,
            maxHp: currMaxHp,
          }));

          // Clear completed quest from array list
          setQuests((prev) => prev.filter((q) => q.id !== activeQ.id));
          triggerToast(`🎁 Completed! Gained +${goldBonus} Gold and +${xpBonus} XP!`, 'loot');

          if (levelUp) {
            triggerToast(`🎉 LEVEL UP! You reached Level ${currLevel}!`, 'info');
          }
        }
        setActiveNPC(null);
        return;
      }

      // 2. Shop Trades actions
      if (action === 'buy_potion_10') {
        if (playerStats.gold >= 10) {
          setPlayerStats((prev) => ({ ...prev, gold: prev.gold - 10 }));
          
          setInventory((prevInv) => {
            const idx = prevInv.findIndex((i) => i.id === 'potion_heal');
            if (idx === -1) {
              return [
                ...prevInv,
                { id: 'potion_heal', name: 'Restorative Red Potion (+30 HP)', type: 'potion', description: 'Restores HP', quantity: 1, color: '#f43f5e' },
              ];
            } else {
              const updated = [...prevInv];
              updated[idx].quantity += 1;
              return updated;
            }
          });

          const node = activeNPC.dialogue.find((n) => n.id === 'bought');
          setDialogNode(node || null);
          triggerToast('🧪 Bought Red healing draught.', 'loot');
        } else {
          const node = activeNPC.dialogue.find((n) => n.id === 'poor');
          setDialogNode(node || null);
        }
        return;
      }

      if (action === 'buy_sword_40') {
        if (playerStats.gold >= 40) {
          setPlayerStats((prev) => ({ ...prev, gold: prev.gold - 40, attack: prev.attack + 8 }));
          
          setInventory((prev) => [
            ...prev,
            { id: 'steel_sword', name: 'Broad Steel Greatsword (+8 ATK)', type: 'weapon', description: 'Heavy battle blade.', quantity: 1, color: '#f59e0b' },
          ]);

          const node = activeNPC.dialogue.find((n) => n.id === 'bought');
          setDialogNode(node || null);
          triggerToast('🗡️ Steel Greatsword equipped! Attack power surged.', 'loot');
        } else {
          const node = activeNPC.dialogue.find((n) => n.id === 'poor');
          setDialogNode(node || null);
        }
        return;
      }
    }

    setActiveNPC(null);
    setDialogNode(null);
  };

  // Live Cheat updates injector
  const handleInjectCheats = (updates: Partial<PlayerStats>) => {
    setPlayerStats((prev) => ({
      ...prev,
      ...updates,
    }));
    triggerToast('💻 Injected custom notepad state patch successfully!', 'loot');
  };

  const handleLoadSaveState = (loaded: any) => {
    if (loaded.playerStats) setPlayerStats(loaded.playerStats);
    if (loaded.inventory) setInventory(loaded.inventory);
    if (loaded.quests) setQuests(loaded.quests);
    if (loaded.currentWorld) setCurrentWorld(loaded.currentWorld);
    if (loaded.activePet) setActivePet(loaded.activePet);
    if (loaded.avatar) setPlayerAvatar(loaded.avatar);
    if (loaded.avatarColor) setAvatarColor(loaded.avatarColor);
    triggerToast('📥 Successfully loaded your RPG saving backup! Welcome back, hero.', 'loot');
  };

  // Dynamic Storyline Act Progression
  const numQuestsCompleted = quests.filter((q) => q.status === 'completed').length;
  const activeSlimeQ = quests.find((q) => q.id === 'quest_slime');
  const activeGoblinQ = quests.find((q) => q.id === 'quest_goblin');

  let currentAct = 1;
  let actTitle = "Act I: Whispers of the Meadowvale Woods";
  let actObjective = "Talk to Elder Aaron in the starting village (around x:40, y:40) to accept a quest to cleanse the forest Slimes.";

  if (activeSlimeQ) {
    currentAct = 1;
    actTitle = "Act I: Cleansing the Bouncy Slimes";
    actObjective = `Defeat bouncy Slimes in Meadowvale forests. Progress: (${activeSlimeQ.currentCount}/${activeSlimeQ.requiredCount}). Return to Elder Aaron when finished!`;
  } else if (activeGoblinQ) {
    currentAct = 2;
    actTitle = "Act II: Subterranean Iron & Goblins";
    actObjective = `Descend into the dark Caves (walk southwest of village to find cave entrances) and defeat the Cave Goblin monster!`;
  } else if (quests.length === 0 && playerStats.gold < 150) {
    currentAct = 3;
    actTitle = "Act III: Eternal Meadowvale Champion";
    actObjective = "Increase your training: Reach Level 3 and gather 150 Gold coins to purchase the master Steel Greatsword from Shopkeeper Lily!";
  } else if (playerStats.gold >= 150) {
    currentAct = 4;
    actTitle = "Epilogue: Legendary Knight of Vivobook Pro";
    actObjective = "You have cleansed the overworld from monsters and defeated the cave goblin! Explore the infinite world generation or customizable character customizer freely.";
  }

  return (
    <div className="min-h-screen bg-slate-950 font-sans antialiased text-slate-100 flex flex-col justify-between">
      
      {/* Visual Navigation Banner */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center font-bold text-indigo-400">
              🕹️
            </div>
            <div>
              <h1 className="font-display font-bold text-base text-white tracking-tight">
                2D Open World RPG
              </h1>
              <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mt-0.5">
                ASUS Vivobook Pro Edition // Procedural Engine
              </p>
            </div>
          </div>

          {/* Quick Tab Selectors */}
          <div className="hidden sm:flex gap-1 bg-slate-900/60 border border-slate-800/80 p-1.2 rounded-2xl">
            <button
              onClick={() => setActiveTab('game')}
              className={`px-4 py-1.5 rounded-xl text-xs font-medium font-sans flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'game'
                  ? 'bg-indigo-500 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Gamepad className="w-4 h-4" />
              Open World
            </button>
            <button
              onClick={() => setActiveTab('avatar')}
              className={`px-4 py-1.5 rounded-xl text-xs font-medium font-sans flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'avatar'
                  ? 'bg-indigo-500 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <User className="w-4 h-4" />
              Avatar Creator
            </button>
            <button
              onClick={() => setActiveTab('notepad')}
              className={`px-4 py-1.5 rounded-xl text-xs font-medium font-sans flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'notepad'
                  ? 'bg-indigo-500 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-4 h-4" />
              Notepad Exporter
            </button>
          </div>
        </div>
      </header>

      {/* Main Layout Grid Content */}
      <main className="max-w-7xl w-full mx-auto px-4 md:px-6 py-6 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Playable Canvas and interactive view column */}
        <section className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6">
          
          {/* Mobile Tab Toggles */}
          <div className="flex sm:hidden gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl w-full">
            <button
              onClick={() => setActiveTab('game')}
              className={`flex-1 py-1.5 text-center text-xs font-medium rounded-lg ${
                activeTab === 'game' ? 'bg-indigo-500 text-white' : 'text-slate-400'
              }`}
            >
              Game
            </button>
            <button
              onClick={() => setActiveTab('avatar')}
              className={`flex-1 py-1.5 text-center text-xs font-medium rounded-lg ${
                activeTab === 'avatar' ? 'bg-indigo-500 text-white' : 'text-slate-400'
              }`}
            >
              Avatar
            </button>
            <button
              onClick={() => setActiveTab('notepad')}
              className={`flex-1 py-1.5 text-center text-xs font-medium rounded-lg ${
                activeTab === 'notepad' ? 'bg-indigo-500 text-white' : 'text-slate-400'
              }`}
            >
              Notepad
            </button>
          </div>

          {activeTab === 'game' && (
            <div className="space-y-4 font-sans">
              
              {/* Dynamic Storyline Banner */}
              <div className="bg-slate-900 border border-indigo-950 rounded-2xl p-4 flex gap-4 items-start shadow-md relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-indigo-500/10 text-indigo-400 text-[9px] font-mono font-bold px-3 py-1 rounded-bl-xl border-l border-b border-indigo-500/20">
                  ACT {currentAct} ACTIVE
                </div>
                <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-xl shrink-0">
                  📖
                </div>
                <div className="space-y-1 pr-16 bg-transparent">
                  <h3 className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-widest mt-0.5">
                    Main Storyline Progression
                  </h3>
                  <h4 className="text-sm font-sans font-bold text-white leading-snug">
                    {actTitle}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {actObjective}
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center bg-slate-900/30 border border-slate-800/65 py-2.5 px-4 rounded-2xl">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                  <span className="text-xs font-mono text-slate-300">
                    Active Area:{' '}
                    <strong className="text-white capitalize">{currentWorld} Map</strong>
                  </span>
                </div>
                <div className="text-[10px] bg-slate-800 font-mono px-2.5 py-1 rounded text-slate-400 uppercase tracking-widest">
                  WASD to move // Target enemies nearby
                </div>
              </div>

              {/* Canvas Render Panel */}
              <GameCanvas
                tiles={currentTiles}
                playerStats={playerStats}
                currentWorld={currentWorld}
                npcs={currentNPCs}
                monsters={currentMonsters}
                playerAvatar={playerAvatar}
                currentAvatarColor={avatarColor}
                onUpdateStats={setPlayerStats}
                onInteractNPC={handleSpeakDialogue}
                onMonsterSlay={handleMonsterSlay}
                onEnterCave={() => {
                  setCurrentWorld('cave');
                  triggerToast('🕳️ Entered the deep subterranean cave system!', 'danger');
                }}
                onLeaveCave={() => {
                  setCurrentWorld('overworld');
                  triggerToast('🌲 Emerged back onto the grass fields of Meadowvale!', 'info');
                }}
                showMessage={triggerToast}
                activePet={activePet}
                caveSpawnPosition={worldMaps?.caveSpawnPosition}
              />
            </div>
          )}

          {activeTab === 'avatar' && (
            <PlayerCustomizer
              onSelectAvatar={(base64OrPreset, color) => {
                setPlayerAvatar(base64OrPreset);
                setAvatarColor(color);
              }}
              currentAvatar={playerAvatar}
              currentColor={avatarColor}
              activePet={activePet}
              onSelectPet={(pet) => {
                setActivePet(pet);
                triggerToast(`❤️ Companion choice updated to: ${pet === 'none' ? 'Solo Traveler' : pet.toUpperCase()}!`, 'info');
              }}
              onClose={() => setActiveTab('game')}
            />
          )}

          {activeTab === 'notepad' && (
            <VivobookNotepad
              playerStats={playerStats}
              inventory={inventory}
              quests={quests}
              currentWorld={currentWorld}
              activePet={activePet}
              avatar={playerAvatar}
              avatarColor={avatarColor}
              onInjectCheats={handleInjectCheats}
              onLoadSaveState={handleLoadSaveState}
            />
          )}
        </section>

        {/* Dashboard Panels sidebar */}
        <aside className="lg:col-span-5 xl:col-span-4 space-y-6">
          <GameUI
            playerStats={playerStats}
            activeDialogNPC={activeNPC}
            activeDialogNode={dialogNode}
            activeQuests={quests}
            bagInventory={inventory}
            onSelectDialogOption={handleSelectDialogueOption}
            onCloseDialog={() => {
              setActiveNPC(null);
              setDialogNode(null);
            }}
            onDrinkPotion={handleDrinkPotion}
            gameMessage={toastMessage}
          />
        </aside>

      </main>

      {/* Decorative footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 text-center text-[10px] text-slate-600 font-mono uppercase tracking-widest">
        🎮 Custom procedural open-world compilations. Fully optimized for ASUS Vivobook Notepad offline runs.
      </footer>

    </div>
  );
}

