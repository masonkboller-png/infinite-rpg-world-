/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Copy, FileDown, Check, Terminal, FileCode, Sliders, AlertCircle } from 'lucide-react';
import { PlayerStats, InventoryItem } from '../types';

interface VivobookNotepadProps {
  playerStats: PlayerStats;
  inventory: InventoryItem[];
  quests: any[];
  currentWorld: 'overworld' | 'cave';
  activePet: 'none' | 'corgi' | 'dragon' | 'slime' | 'wolf';
  avatar: string;
  avatarColor: string;
  onInjectCheats: (updates: Partial<PlayerStats>) => void;
  onLoadSaveState: (loaded: any) => void;
}

export function VivobookNotepad({
  playerStats,
  inventory,
  quests,
  currentWorld,
  activePet,
  avatar,
  avatarColor,
  onInjectCheats,
  onLoadSaveState,
}: VivobookNotepadProps) {
  const [copied, setCopied] = useState(false);
  const [jsonText, setJsonText] = useState('');
  const [injectorError, setInjectorError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'exporter' | 'cheat_notepad' | 'save_load'>('exporter');
  const [pasteValue, setPasteValue] = useState('');
  const [copiedSave, setCopiedSave] = useState(false);
  const [activeSaveKey, setActiveSaveKey] = useState('');

  // Encrypt player stats and level settings to base64 saving key
  useEffect(() => {
    try {
      const stateObj = {
        playerStats,
        inventory,
        quests,
        currentWorld,
        activePet,
        avatar,
        avatarColor,
        timestamp: new Date().toISOString(),
      };
      const b64 = btoa(JSON.stringify(stateObj));
      setActiveSaveKey(b64);
    } catch (e) {
      setActiveSaveKey('');
    }
  }, [playerStats, inventory, quests, currentWorld, activePet, avatar, avatarColor]);

  const handleCopySaveKey = () => {
    navigator.clipboard.writeText(activeSaveKey);
    setCopiedSave(true);
    setTimeout(() => setCopiedSave(false), 2000);
  };

  const handleRestoreSave = () => {
    if (!pasteValue.trim()) {
      alert('Please paste a valid save code key first!');
      return;
    }
    try {
      const decoded = JSON.parse(atob(pasteValue.trim()));
      if (decoded && decoded.playerStats) {
        onLoadSaveState(decoded);
      } else {
        alert('Could not decode progress key. Make sure you copied the entire save key format.');
      }
    } catch (err) {
      alert('Failed to parse save key: Encrypted code syntax is corrupted.');
    }
  };

  // Load the current game state as standard editable JSON in the mini notepad
  useEffect(() => {
    const config = {
      player: {
        hp: playerStats.hp,
        level: playerStats.level,
        xp: playerStats.xp,
        gold: playerStats.gold,
        attack: playerStats.attack,
        speed: playerStats.speed,
      },
      cheats_activated: true,
      current_time: new Date().toLocaleTimeString(),
    };
    setJsonText(JSON.stringify(config, null, 2));
  }, [playerStats]);

  const handleInject = () => {
    try {
      const parsed = JSON.parse(jsonText);
      if (parsed && typeof parsed.player === 'object') {
        const stats = parsed.player;
        onInjectCheats({
          hp: Math.min(stats.hp ?? 100, stats.hp ?? 100),
          level: stats.level ?? 1,
          xp: stats.xp ?? 0,
          gold: stats.gold ?? 0,
          attack: stats.attack ?? 10,
          speed: stats.speed ?? 4,
        });
        setInjectorError(null);
        alert('💻 Code injected successfully! Your core player variables have been customized.');
      } else {
        setInjectorError('Invalid JSON format scheme. Must include direct "player" fields.');
      }
    } catch (e: any) {
      setInjectorError(`Syntax Error: ${e.message}`);
    }
  };

  // Generate the absolute standalone game code that will run in Windows Notepad!
  const generateStandaloneHTML = () => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2D Open World RPG: ASUS Vivobook Edition</title>
    <!-- Tailwind CSS Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #0f172a; margin: 0; overflow: hidden; color: #f8fafc; }
        #game-canvas { display: block; background-color: #1e293b; border-radius: 12px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.4); }
        .font-display { font-family: 'Space Grotesk', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen p-4">

    <!-- Container -->
    <div class="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col gap-4">
        
        <!-- Header -->
        <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
                <h1 class="text-2xl font-display font-semibold tracking-tight text-white flex items-center gap-2">
                    🛸 Retro Open World RPG
                </h1>
                <p class="text-xs text-sky-400 font-mono mt-0.5">Offline ASUS Vivobook Native Edition</p>
            </div>
            <div class="flex items-center gap-3">
                <div class="bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded text-[10px] font-mono text-indigo-400">
                    Offline Mode Enabled
                </div>
            </div>
        </div>

        <!-- Controls Hint Banner -->
        <div class="grid grid-cols-3 gap-2 bg-slate-950/50 p-2.5 rounded-lg text-center text-xs font-mono border border-slate-800/60 text-slate-400">
            <div>Move: <span class="bg-slate-800 text-white px-1.5 py-0.5 rounded">W A S D</span> / <span class="bg-slate-800 text-white px-1.5 py-0.5 rounded">Arrows</span></div>
            <div>Attack: <span class="bg-slate-800 text-white px-1.5 py-0.5 rounded">SPACEBAR</span></div>
            <div>Action: Click or Tap adjacent grids</div>
        </div>

        <!-- Active View Screen -->
        <div class="relative flex flex-col md:flex-row gap-6">
            
            <!-- Canvas Container -->
            <div class="flex-1 flex flex-col items-center">
                <canvas id="game-canvas"></canvas>
                <div class="flex gap-4 mt-3 w-full max-w-lg">
                    <button id="btn-potion" class="flex-1 py-1.5 bg-rose-500 hover:bg-rose-600 rounded-lg text-xs font-bold text-white transition-all shadow-md">
                        Healing Drink (+30 HP)
                    </button>
                    <button id="btn-mana" class="flex-1 py-1.5 bg-blue-500 hover:bg-blue-600 rounded-lg text-xs font-bold text-white transition-all shadow-md">
                        Mana Drink (+30 MP)
                    </button>
                </div>
            </div>

            <!-- Stats HUD Panel -->
            <div class="w-full md:w-64 bg-slate-950/40 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
                <div>
                    <h3 class="text-xs font-mono uppercase tracking-widest text-slate-400 border-b border-slate-800 pb-2 mb-3">Hero Status</h3>
                    
                    <div class="space-y-3.5 text-sm">
                        <!-- Level & XP -->
                        <div>
                            <div class="flex justify-between text-xs font-mono mb-1">
                                <span class="text-slate-300 font-bold">Level <span id="lbl-level">1</span></span>
                                <span class="text-slate-500"><span id="lbl-xp">0</span>/<span id="lbl-max-xp">100</span> XP</span>
                            </div>
                            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                                <div id="bar-xp" class="bg-sky-400 h-full transition-all duration-300" style="width: 0%"></div>
                            </div>
                        </div>

                        <!-- HP -->
                        <div>
                            <div class="flex justify-between text-xs font-mono mb-1">
                                <span class="text-rose-400 font-bold">Health Points</span>
                                <span class="text-rose-300"><span id="lbl-hp">100</span>/100 HP</span>
                            </div>
                            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                                <div id="bar-hp" class="bg-rose-500 h-full transition-all duration-300" style="width: 100%"></div>
                            </div>
                        </div>

                        <!-- MP -->
                        <div>
                            <div class="flex justify-between text-xs font-mono mb-1">
                                <span class="text-sky-400 font-bold">Mana energy</span>
                                <span class="text-sky-300"><span id="lbl-mp">50</span>/50 MP</span>
                            </div>
                            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                                <div id="bar-mp" class="bg-sky-500 h-full transition-all duration-300" style="width: 100%"></div>
                            </div>
                        </div>

                        <!-- Gold -->
                        <div class="bg-slate-900 border border-slate-800 p-2.5 rounded-lg flex items-center justify-between">
                            <span class="text-xs font-mono text-slate-400">My gold</span>
                            <span class="text-amber-400 font-bold text-lg font-mono">🪙 <span id="lbl-gold">15</span>g</span>
                        </div>
                    </div>
                </div>

                <div class="pt-4 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
                    🕹️ ASUS Vivobook Edition. Single-page HTML runtime compilation.
                </div>
            </div>

        </div>
    </div>

    <!-- Retro Synthesizer Engine & Canvas Scripts -->
    <script>
        // Web Audio Synthesizer for Retro Game Noises
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        function playNoise(freq, duration, type = 'sine') {
            try {
                if(audioCtx.state === 'suspended') audioCtx.resume();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = type;
                osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(10, audioCtx.currentTime + duration);
                gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
                gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + duration);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.start();
                osc.stop(audioCtx.currentTime + duration);
            } catch(e){}
        }

        // Simplistic Procedural Open World 2D Game
        const canvas = document.getElementById("game-canvas");
        const ctx = canvas.getContext("2d");
        
        canvas.width = 480;
        canvas.height = 360;

        // Player Stats
        let player = {
            x: 10, y: 10,
            hp: 100, maxHp: 100,
            mp: 50, maxMp: 50,
            level: 1, xp: 0, maxXp: 100,
            gold: 35, attack: 12
        };

        // Procedural world grid (30x30 for offline simplicity)
        const MAP_SIZE = 35;
        let map = [];
        for (let y = 0; y < MAP_SIZE; y++) {
            let row = [];
            for (let x = 0; x < MAP_SIZE; x++) {
                let type = 'meadow';
                let walkable = true;
                if (x === 0 || y === 0 || x === MAP_SIZE - 1 || y === MAP_SIZE - 1) {
                    type = 'water'; walkable = false;
                } else if (Math.sin(x*0.5) + Math.cos(y*0.5) > 0.8) {
                    type = 'forest';
                }
                row.push({ x, y, type, walkable });
            }
            map.push(row);
        }

        // Place cave door
        map[8][22].type = 'cave';

        // Monsters spawning list
        let monsters = [
            { id: 1, name: "Forest Slime", x: 6, y: 12, hp: 20, maxHp: 20, color: '#10b981' },
            { id: 2, name: "Cave Wolf", x: 18, y: 7, hp: 35, maxHp: 35, color: '#94a3b8' },
            { id: 3, name: "Underground Goblin", x: 26, y: 22, hp: 45, maxHp: 45, color: '#f43f5e' }
        ];

        // Drawing parameters
        const TILE_SIZE = 32;

        function updateHUD() {
            document.getElementById("lbl-level").innerText = player.level;
            document.getElementById("lbl-xp").innerText = player.xp;
            document.getElementById("lbl-max-xp").innerText = player.maxXp;
            document.getElementById("lbl-hp").innerText = player.hp;
            document.getElementById("lbl-mp").innerText = player.mp;
            document.getElementById("lbl-gold").innerText = player.gold;

            document.getElementById("bar-hp").style.width = \`\${(player.hp / player.maxHp) * 100}%\`;
            document.getElementById("bar-mp").style.width = \`\${(player.mp / player.maxMp) * 100}%\`;
            document.getElementById("bar-xp").style.width = \`\${(player.xp / player.maxXp) * 100}%\`;
        }

        // Listeners for triggers
        document.getElementById("btn-potion").addEventListener("click", () => {
            if (player.gold >= 10) {
                player.gold -= 10;
                player.hp = Math.min(player.maxHp, player.hp + 30);
                playNoise(800, 0.4, 'sine');
                updateHUD();
            }
        });

        document.getElementById("btn-mana").addEventListener("click", () => {
            if (player.gold >= 10) {
                player.gold -= 10;
                player.mp = Math.min(player.maxMp, player.mp + 30);
                playNoise(900, 0.35, 'triangle');
                updateHUD();
            }
        });

        // Walking keys
        window.addEventListener("keydown", (e) => {
            let dx = 0, dy = 0;
            if (e.key === 'w' || e.key === 'ArrowUp') dy = -1;
            if (e.key === 's' || e.key === 'ArrowDown') dy = 1;
            if (e.key === 'a' || e.key === 'ArrowLeft') dx = -1;
            if (e.key === 'd' || e.key === 'ArrowRight') dx = 1;

            if (dx !== 0 || dy !== 0) {
                const targetX = player.x + dx;
                const targetY = player.y + dy;
                if (targetX >= 0 && targetX < MAP_SIZE && targetY >= 0 && targetY < MAP_SIZE) {
                    if (map[targetY][targetX].walkable) {
                        player.x = targetX;
                        player.y = targetY;
                        playNoise(220, 0.08, 'sawtooth');
                    }
                }
            }

            // Attack triggering space
            if (e.key === ' ') {
                e.preventDefault();
                attackNearby();
            }
        });

        function attackNearby() {
            playNoise(600, 0.15, 'sawtooth');
            monsters.forEach(m => {
                let dist = Math.hypot(m.x - player.x, m.y - player.y);
                if (dist < 2.5) {
                    m.hp -= player.attack;
                    playNoise(180, 0.3, 'square');
                    if (m.hp <= 0) {
                        player.xp += 30;
                        player.gold += m.maxHp / 2;
                        if (player.xp >= player.maxXp) {
                            player.level++;
                            player.xp = 0;
                            player.attack += 5;
                            player.maxHp += 15;
                            player.hp = player.maxHp;
                            playNoise(1200, 0.6, 'sine');
                        }
                    }
                }
            });
            monsters = monsters.filter(m => m.hp > 0);
            updateHUD();
        }

        // Gameloop drawing
        function render() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // CAMERA CENTER ON PLAYER
            const cameraX = Math.round(player.x * TILE_SIZE - canvas.width / 2);
            const cameraY = Math.round(player.y * TILE_SIZE - canvas.height / 2);

            // Draw tiles
            for (let y = 0; y < MAP_SIZE; y++) {
                for (let x = 0; x < MAP_SIZE; x++) {
                    const tx = x * TILE_SIZE - cameraX;
                    const ty = y * TILE_SIZE - cameraY;

                    if (tx > -TILE_SIZE && tx < canvas.width && ty > -TILE_SIZE && ty < canvas.height) {
                        const cell = map[y][x];
                        if (cell.type === 'water') {
                            ctx.fillStyle = '#1e3a8a';
                        } else if (cell.type === 'forest') {
                            ctx.fillStyle = '#065f46';
                        } else if (cell.type === 'cave') {
                            ctx.fillStyle = '#475569';
                        } else {
                            ctx.fillStyle = '#15803d'; // green meadow
                        }
                        ctx.fillRect(tx, ty, TILE_SIZE - 1, TILE_SIZE - 1);
                        
                        // draw details
                        if (cell.type === 'forest') {
                            ctx.fillStyle = '#10b981';
                            ctx.fillRect(tx + 8, ty + 4, 16, 20);
                        }
                    }
                }
            }

            // Draw Monsters
            monsters.forEach(m => {
                const tx = m.x * TILE_SIZE - cameraX;
                const ty = m.y * TILE_SIZE - cameraY;
                ctx.fillStyle = m.color;
                ctx.beginPath();
                ctx.arc(tx + TILE_SIZE/2, ty + TILE_SIZE/2, 10, 0, Math.PI*2);
                ctx.fill();

                // HP Bar
                ctx.fillStyle = '#000';
                ctx.fillRect(tx + 2, ty - 6, 28, 4);
                ctx.fillStyle = '#ef4444';
                ctx.fillRect(tx + 2, ty - 6, Math.max(0, 28 * (m.hp / m.maxHp)), 4);
            });

            // Draw Player
            const px = player.x * TILE_SIZE - cameraX;
            const py = player.y * TILE_SIZE - cameraY;
            ctx.fillStyle = '#fbbf24'; // player gold circle
            ctx.beginPath();
            ctx.arc(px + TILE_SIZE/2, py + TILE_SIZE/2, 12, 0, Math.PI*2);
            ctx.fill();
            
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(px + 4, py + 12, 8, 8); // eyes representation

            requestAnimationFrame(render);
        }

        // Initialize HUD and kick-start
        updateHUD();
        render();
    </script>
</body>
</html>`;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generateStandaloneHTML());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = () => {
    const blob = new Blob([generateStandaloneHTML()], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = '2d_open_world_game.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl transition-all">
      
      {/* Title Bar - Windows Notepad Style */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-sky-400" />
          <span className="text-xs font-mono font-medium text-slate-300">
            open_world_rules.json - Notepad (ASUS Vivobook Pro 15)
          </span>
        </div>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
        </div>
      </div>

      {/* Internal Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-950/45 px-2">
        <button
          onClick={() => setActiveTab('exporter')}
          className={`px-4 py-2 text-[11px] font-mono border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'exporter'
              ? 'border-sky-500 text-sky-400 bg-slate-900/40'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          Notepad HTML Exporter
        </button>
        <button
          onClick={() => setActiveTab('cheat_notepad')}
          className={`px-4 py-2 text-[11px] font-mono border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'cheat_notepad'
              ? 'border-sky-500 text-sky-400 bg-slate-900/40'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          Live JSON Game Cheat
        </button>
        <button
          onClick={() => setActiveTab('save_load')}
          className={`px-4 py-2 text-[11px] font-mono border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'save_load'
              ? 'border-emerald-500 text-emerald-400 bg-slate-900/40'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>💾</span>
          Notepad Save & Load Key
        </button>
      </div>

      {/* Container Content */}
      <div className="p-5">
        {activeTab === 'exporter' ? (
          <div className="space-y-4">
            <h4 className="text-sm font-sans font-semibold text-white">
              Export Game to Your ASUS Vivobook Notepad!
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              To play this 2D Open World adventure directly from your Vivobook desktop without internet, export the single-page bundle underneath. Paste it into your standard Windows Notepad!
            </p>

            <ul className="space-y-2 text-[11px] font-mono text-slate-400 bg-slate-950/60 border border-slate-800/80 p-3 rounded-lg">
              <li className="flex gap-2">
                <span className="text-sky-400">1.</span> Click the "Download HTML Game" button below.
              </li>
              <li className="flex gap-2">
                <span className="text-sky-400">2.</span> Or, click "Copy Code", open Notepad on your PC, paste it, and save as <strong className="text-white">my_game.html</strong> (use "All Files" in Notepad encoding).
              </li>
              <li className="flex gap-2">
                <span className="text-sky-400">3.</span> Double-click <strong className="text-emerald-400">my_game.html</strong> from your file explorer to boot into procedural RPG realms instantly!
              </li>
            </ul>

            <div className="flex gap-3">
              <button
                onClick={downloadFile}
                className="flex-1 bg-sky-600 hover:bg-sky-500 text-white font-sans font-medium py-2 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-sky-500/10 cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                Download Game File
              </button>
              <button
                onClick={copyToClipboard}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-sans font-medium px-4 py-2 rounded-xl text-xs transition-all flex items-center justify-center gap-2 border border-slate-700 cursor-pointer"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
          </div>
        ) : activeTab === 'save_load' ? (
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-sans font-semibold text-white">
                💾 Save & Load Game Key
              </h4>
              <p className="text-xs text-slate-400">
                Generate or load your progress using an encrypted Base64 key. You can save this key in your ASUS Vivobook Notepad text file!
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* SAVE section */}
              <div className="space-y-3 p-4 bg-slate-950/40 border border-slate-800/80 rounded-xl flex flex-col justify-between">
                <div>
                  <h5 className="text-[11px] font-mono uppercase text-emerald-400 font-bold mb-2">
                    📋 Generate Save Key
                  </h5>
                  <p className="text-[10px] text-slate-400 mb-3 leading-relaxed">
                    This encrypted key encodes your HP, Level, XP, Gold, Items, Active Quests, equipped Pet Companion, and Custom Avatar.
                  </p>
                  <textarea
                    readOnly
                    onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                    value={activeSaveKey}
                    className="w-full h-24 bg-slate-950 font-mono text-[9px] text-slate-300 border border-slate-800 rounded-lg p-2 focus:outline-none select-all"
                  />
                </div>
                <button
                  onClick={handleCopySaveKey}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-indigo-100 font-sans font-bold text-xs py-2 rounded-lg cursor-pointer transition-all active:scale-95 text-center"
                >
                  {copiedSave ? '✅ Save Key Copied!' : '📋 Copy Save Key to Notepad'}
                </button>
              </div>

              {/* LOAD section */}
              <div className="space-y-3 p-4 bg-slate-950/40 border border-slate-800/80 rounded-xl flex flex-col justify-between">
                <div>
                  <h5 className="text-[11px] font-mono uppercase text-amber-400 font-bold mb-2">
                    📥 Restore From Notepad Save Key
                  </h5>
                  <p className="text-[10px] text-slate-400 mb-3 leading-relaxed">
                    Paste your saved Base64 code below, then click "Restore Game" to instantly load your progress.
                  </p>
                  <textarea
                    value={pasteValue}
                    onChange={(e) => setPasteValue(e.target.value)}
                    placeholder="Paste saved key starting with eyJ..."
                    className="w-full h-24 bg-slate-950 font-mono text-[9px] text-amber-300 border border-slate-800 rounded-lg p-2 focus:outline-none placeholder-slate-600 focus:border-amber-500"
                  />
                </div>
                <button
                  onClick={handleRestoreSave}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-bold text-xs py-2 rounded-lg cursor-pointer transition-all active:scale-95 text-center"
                >
                  ⚙️ Restore Game Progress
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-sans font-semibold text-white">
                  Live JSON Config Notepad
                </h4>
                <p className="text-[10px] text-slate-400">
                  Update your active values. Hit "Inject" to instantly cheat or load custom stats!
                </p>
              </div>
              <button
                onClick={handleInject}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-semibold px-3 py-1.5 rounded-lg text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow"
              >
                Inject Code
              </button>
            </div>

            {injectorError && (
              <div className="bg-rose-500/10 border border-rose-500/20 p-2.5 rounded-lg flex items-center gap-2 text-[11px] text-rose-400 font-mono">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {injectorError}
              </div>
            )}

            <div className="relative">
              <textarea
                value={jsonText}
                onChange={(e) => setJsonText(e.target.value)}
                className="w-full h-44 bg-slate-950 font-mono text-[11px] text-emerald-400 border border-slate-800 rounded-xl p-3 focus:outline-none focus:border-sky-500 resize-none select-text"
                spellCheck={false}
              />
              <div className="absolute bottom-2.5 right-3 text-[9px] font-mono text-slate-500">
                UTF-8 // JSON Mode
              </div>
            </div>
          </div>
        )}
      </div>

    </div>
  );
}
