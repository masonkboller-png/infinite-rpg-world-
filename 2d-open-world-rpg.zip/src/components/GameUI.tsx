/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PlayerStats, NPC, DialogueNode, Quest, InventoryItem } from '../types';
import { Shield, Sparkles, Scroll, Coins, Backpack, Heart, Compass, CheckCircle2 } from 'lucide-react';

interface GameUIProps {
  playerStats: PlayerStats;
  activeDialogNPC: NPC | null;
  activeDialogNode: DialogueNode | null;
  activeQuests: Quest[];
  bagInventory: InventoryItem[];
  onSelectDialogOption: (action?: string, nextId?: string) => void;
  onCloseDialog: () => void;
  onDrinkPotion: (id: string) => void;
  gameMessage: { text: string; type: string } | null;
}

export function GameUI({
  playerStats,
  activeDialogNPC,
  activeDialogNode,
  activeQuests,
  bagInventory,
  onSelectDialogOption,
  onCloseDialog,
  onDrinkPotion,
  gameMessage,
}: GameUIProps) {
  // Render XP percentage progress width
  const xpPercent = Math.min(100, Math.floor((playerStats.xp / playerStats.maxXp) * 100));
  // Render HP percentage progress width
  const hpPercent = Math.min(100, Math.floor((playerStats.hp / playerStats.maxHp) * 100));

  return (
    <div className="space-y-6 text-slate-100">
      
      {/* 1. Header Toast / Live Stream Notifications */}
      {gameMessage && (
        <div
          className={`px-4 py-3 rounded-2xl border transition-all text-xs font-mono flex items-center justify-between shadow-lg ${
            gameMessage.type === 'danger'
              ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
              : gameMessage.type === 'loot'
              ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
              : 'bg-slate-800/80 border-slate-700/80 text-emerald-400'
          }`}
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
            <span>{gameMessage.text}</span>
          </div>
          <span className="text-[10px] text-slate-500 uppercase">System log</span>
        </div>
      )}

      {/* 2. Core Dashboard Stats HUD */}
      <div className="bg-slate-950/40 border border-slate-800/80 rounded-3xl p-5 space-y-4">
        
        {/* Core Profile level and experience */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center font-display font-semibold text-lg text-indigo-400">
              {playerStats.level}
            </div>
            <div>
              <h3 className="font-sans font-semibold text-sm text-white">Hero Level</h3>
              <p className="text-[10px] font-mono text-slate-400 lowercase">
                {playerStats.xp} / {playerStats.maxXp} experience points
              </p>
            </div>
          </div>
          <span className="text-[10px] bg-slate-900 border border-slate-800 font-mono px-2.5 py-1 rounded-full text-slate-400 uppercase tracking-wider">
            Active Character
          </span>
        </div>

        {/* XP Bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest">
            <span>Next Level</span>
            <span>{xpPercent}%</span>
          </div>
          <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-indigo-500 h-full transition-all duration-300"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
        </div>

        {/* Dynamic Vitals Indicators grids */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Health Points */}
          <div className="bg-slate-900/40 border border-slate-800/60 p-3 rounded-2xl space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-sans font-medium text-slate-300 flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-rose-500 shrink-0" />
                Vigor HP
              </span>
              <span className="font-mono text-rose-400 font-semibold">
                {playerStats.hp} <span className="text-slate-600">/</span> {playerStats.maxHp}
              </span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  hpPercent < 30 ? 'bg-rose-600 animate-pulse' : 'bg-rose-500'
                }`}
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          {/* Wallet Gold */}
          <div className="bg-slate-900/40 border border-slate-800/60 p-3 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center">
                <Coins className="text-amber-400 w-4.5 h-4.5" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Wallet Balance</span>
                <span className="font-display font-bold text-base text-amber-300">
                  {playerStats.gold}<span className="text-xs text-amber-500 ml-0.5">g</span>
                </span>
              </div>
            </div>
            <div className="text-[10px] font-mono bg-slate-950/80 text-amber-400 border border-amber-500/10 px-2 py-0.5 rounded">
              🪙 coins
            </div>
          </div>

        </div>

      </div>

      {/* 3. Quest Log / Elder Aaron Tracker Section */}
      <div className="bg-slate-950/40 border border-slate-800/80 rounded-3xl p-5 space-y-4">
         <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 flex items-center gap-1.5 border-b border-slate-800 pb-2">
           <Scroll className="w-4 h-4 text-indigo-400" />
           Elder Quests Journal ({activeQuests.length})
         </h3>
         
         {activeQuests.length === 0 ? (
           <div className="text-center py-4 text-xs text-slate-500 font-sans flex flex-col items-center gap-2">
             <Compass className="w-6 h-6 text-slate-600 shrink-0" />
             Talk to Elder Aaron in the starting village to sign up for quests.
           </div>
         ) : (
           <div className="space-y-3">
             {activeQuests.map((quest) => (
               <div
                 key={quest.id}
                 className={`p-3 rounded-2xl border transition-all ${
                   quest.status === 'completed'
                     ? 'bg-emerald-500/5 border-emerald-500/25'
                     : 'bg-slate-900/40 border-slate-800/60'
                 }`}
               >
                 <div className="flex justify-between items-start">
                   <div>
                     <h4 className="text-xs font-sans font-semibold text-white flex items-center gap-1.5">
                       {quest.status === 'completed' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                       {quest.title}
                     </h4>
                     <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                       {quest.description}
                     </p>
                   </div>
                   <span
                     className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase ${
                       quest.status === 'completed'
                         ? 'bg-emerald-500/20 text-emerald-300'
                         : 'bg-indigo-500/10 text-indigo-300'
                     }`}
                   >
                     {quest.status}
                   </span>
                 </div>

                 {/* Quest Progress bar */}
                 {quest.status !== 'completed' && (
                   <div className="mt-3.5 space-y-1">
                     <div className="flex justify-between text-[9px] font-mono text-slate-500">
                       <span>Target Goals</span>
                       <span>
                         {quest.currentCount} / {quest.requiredCount}
                       </span>
                     </div>
                     <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden">
                       <div
                         className="bg-indigo-400 h-full transition-all"
                         style={{ width: `${Math.min(100, (quest.currentCount / quest.requiredCount) * 100)}%` }}
                       />
                     </div>
                   </div>
                 )}

                 {/* Quest Loot detail */}
                 <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-2 pt-2 border-t border-slate-800/50">
                   <span>💎 XP Reward: +{quest.xpReward}</span>
                   <span>🪙 Gold Reward: +{quest.goldReward}g</span>
                 </div>
               </div>
             ))}
           </div>
         )}
      </div>

      {/* 4. Active Bag / Inventory Component */}
      <div className="bg-slate-950/40 border border-slate-800/80 rounded-3xl p-5 space-y-4">
        <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 flex items-center gap-1.5 border-b border-slate-800 pb-2">
          <Backpack className="w-4 h-4 text-sky-400" />
          Gear Backpack ({bagInventory.reduce((acc, current) => acc + current.quantity, 0)} items)
        </h3>

        {bagInventory.length === 0 ? (
          <div className="text-center py-4 text-xs text-slate-500 font-sans">
             Your pack is empty! Visit Lilys Shop to buy healing brews.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
             {bagInventory.map((item) => (
               <div
                 key={item.id}
                 className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-2xl flex items-center justify-between"
               >
                 <div className="flex items-center gap-2">
                   <div
                     className="w-10 h-10 rounded-xl flex items-center justify-center text-sm border font-bold"
                     style={{
                       backgroundColor: item.color ? `${item.color}15` : '#1e293b40',
                       borderColor: item.color || '#334155'
                     }}
                   >
                     {item.type === 'weapon' ? '⚔️' : item.type === 'armor' ? '🛡️' : '🧪'}
                   </div>
                   <div>
                     <span className="text-xs font-sans font-medium text-white block">
                       {item.name}
                     </span>
                     <span className="text-[9px] font-mono text-slate-400 block mt-0.5">
                       {item.quantity} units {item.type === 'weapon' ? '(equipped)' : ''}
                     </span>
                   </div>
                 </div>

                 {item.type === 'potion' && (
                   <button
                     onClick={() => onDrinkPotion(item.id)}
                     className="bg-indigo-600 hover:bg-indigo-500 border border-indigo-400/20 text-white font-sans text-[10px] font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition-all active:scale-95 shadow"
                   >
                     Use Potion
                   </button>
                 )}
               </div>
             ))}
          </div>
        )}
      </div>

      {/* 5. Branching Dialog Panel Modal Overlay */}
      {activeDialogNPC && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-slate-100 flex flex-col gap-4 shadow-2xl relative">
            <button
              onClick={onCloseDialog}
              className="absolute top-4 right-4 text-slate-500 hover:text-white font-mono text-xs cursor-pointer bg-slate-800 px-2 py-1 rounded"
            >
              esc [x]
            </button>

            {/* NPC Header Title */}
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow"
                style={{ backgroundColor: activeDialogNPC.color }}
              >
                🧙
              </div>
              <div>
                <h3 className="font-sans font-bold text-white text-lg">{activeDialogNPC.name}</h3>
                <span className="text-[10px] font-mono uppercase text-sky-400 tracking-wider">Dialogue interaction</span>
              </div>
            </div>

            {/* Speaking text */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl min-h-[80px] text-sm text-slate-300 leading-relaxed font-sans">
              {activeDialogNode?.text}
            </div>

            {/* User Dialogue Choices list */}
            <div className="space-y-2 mt-2">
              {activeDialogNode?.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => onSelectDialogOption(option.action, option.nextId)}
                  className="w-full text-left p-3 bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 rounded-xl text-xs text-sky-300 hover:text-sky-200 transition-all font-mono flex items-center justify-between group cursor-pointer"
                >
                  <span>➜ {option.text}</span>
                  <span className="text-[10px] text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">Select option</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
