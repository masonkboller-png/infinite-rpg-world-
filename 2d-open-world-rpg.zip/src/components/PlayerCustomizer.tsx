/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Upload, User, Sparkles, Wand2, Shield, Eye } from 'lucide-react';

interface PlayerCustomizerProps {
  onSelectAvatar: (base64OrPreset: string, customColor: string) => void;
  currentAvatar: string;
  currentColor: string;
  activePet?: 'none' | 'corgi' | 'dragon' | 'slime' | 'wolf';
  onSelectPet?: (pet: 'none' | 'corgi' | 'dragon' | 'slime' | 'wolf') => void;
  onClose?: () => void;
}

const COLOR_PALETTES = [
  { name: 'ASUS Teal', value: '#0ea5e9' },
  { name: 'Forest Green', value: '#10b981' },
  { name: 'Sunset Amber', value: '#f59e0b' },
  { name: 'Chrimson Rose', value: '#f43f5e' },
  { name: 'Deep Indigo', value: '#6366f1' },
  { name: 'Cyber Purple', value: '#d946ef' },
];

const PRESETS = [
  { id: 'knight', name: 'Vivobook Knight', desc: 'Default valiant swordfighter' },
  { id: 'mage', name: 'Code Sorcerer', desc: 'Wields the mystical typescript nodes' },
  { id: 'rouge', name: 'Open-World Nomad', desc: 'Swift and agile woodland explorer' },
];

const PETS_LIST = [
  { id: 'none', name: 'No Companion', emoji: '✖', desc: 'Travel the world alone' },
  { id: 'corgi', name: 'Cute Corgi', emoji: '🐶', desc: 'Bounces happily at your heels' },
  { id: 'dragon', name: 'Baby Dragon', emoji: '🐉', desc: 'Flaps wings and spits warm embers' },
  { id: 'slime', name: 'Tame Slime', emoji: '🟢', desc: 'Squishes rhythmically behind you' },
  { id: 'wolf', name: 'Shadow Wolf', emoji: '🐺', desc: 'Stalks ahead of danger alertly' },
] as const;

export function PlayerCustomizer({
  onSelectAvatar,
  currentAvatar,
  currentColor,
  activePet = 'none',
  onSelectPet,
  onClose,
}: PlayerCustomizerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedColor, setSelectedColor] = useState(currentColor);
  const [selectedPreset, setSelectedPreset] = useState('knight');
  const [dragActive, setDragActive] = useState(false);
  const [customImage, setCustomImage] = useState<string | null>(null);

  useEffect(() => {
    // If the current avatar looks like a Base64 string, set as custom image
    if (currentAvatar.startsWith('data:image/')) {
      setCustomImage(currentAvatar);
    }
  }, [currentAvatar]);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file (PNG/JPG)!');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      setCustomImage(base64);
      onSelectAvatar(base64, selectedColor);
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handlePresetSelect = (kind: string) => {
    setSelectedPreset(kind);
    setCustomImage(null);
    onSelectAvatar(kind, selectedColor);
  };

  const handleColorChange = (colorVal: string) => {
    setSelectedColor(colorVal);
    onSelectAvatar(customImage || selectedPreset, colorVal);
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-slate-100 max-w-xl mx-auto space-y-6 shadow-2xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-sans font-semibold tracking-tight text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-sky-400" />
            Character Creation & Companions
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Build your avatar, choose your pet companion, or drop a custom photo to roam!
          </p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-xs font-mono px-3 py-1 bg-indigo-600 hover:bg-indigo-500 rounded text-slate-100 cursor-pointer transition-all active:scale-95"
          >
            Apply & Close
          </button>
        )}
      </div>

      {/* Preset vs Custom Picture Upload */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Presets List */}
        <div className="space-y-3">
          <label className="text-xs font-mono font-medium text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-sky-400" />
            Select Character Archetype
          </label>
          <div className="space-y-2">
            {PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handlePresetSelect(preset.id)}
                className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between group cursor-pointer ${
                  (!customImage && selectedPreset === preset.id)
                    ? 'bg-indigo-500/10 border-indigo-500 text-white'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="text-xs font-medium font-sans flex items-center gap-1">
                    {preset.name}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{preset.desc}</div>
                </div>
                {!customImage && selectedPreset === preset.id && (
                  <div className="w-2 h-2 rounded-full bg-indigo-400 shadow-indigo" />
                )}
              </button>
            ))}
          </div>

          {/* Color Palettes Selection */}
          <div className="pt-2">
            <label className="text-xs font-mono font-medium text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-2">
              <Wand2 className="w-3.5 h-3.5 text-sky-400" />
              Tunic Accent Color
            </label>
            <div className="flex gap-2 flex-wrap pb-2">
              {COLOR_PALETTES.map((color) => (
                <button
                  key={color.name}
                  onClick={() => handleColorChange(color.value)}
                  style={{ backgroundColor: color.value }}
                  className={`w-7 h-7 rounded-full border-2 transition-all cursor-pointer ${
                    selectedColor === color.value ? 'border-white scale-110 shadow-lg' : 'border-slate-950 hover:scale-105'
                  }`}
                  title={color.name}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Custom Picture Uploader */}
        <div className="space-y-3 flex flex-col justify-between">
          <div>
            <label className="text-xs font-mono font-medium text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-2">
              <Upload className="w-3.5 h-3.5 text-sky-400" />
              Upload Your Own Picture
            </label>
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={triggerUpload}
              className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer flex flex-col items-center justify-center transition-all ${
                dragActive
                  ? 'border-sky-400 bg-sky-500/10'
                  : customImage
                  ? 'border-emerald-500/50 bg-emerald-500/5'
                  : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-950/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                className="hidden"
              />

              {customImage ? (
                <div className="space-y-2">
                  <div className="relative mx-auto w-16 h-16 rounded-xl overflow-hidden border border-emerald-500 shadow-md flex items-center justify-center bg-slate-900">
                    <img
                      src={customImage}
                      alt="Custom Avatar"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/35 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Eye className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono">Custom Image Active!</div>
                </div>
              ) : (
                <div className="py-2.5">
                  <User className="w-8 h-8 mx-auto text-slate-500 mb-2 group-hover:text-slate-400" />
                  <p className="text-[11px] text-slate-300 font-sans">
                    Drag and drop your hero picture here
                  </p>
                  <p className="text-[9px] text-slate-500 font-mono mt-1">
                    Or click to browse files
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Quick Preview Badge */}
          <div className="bg-slate-950/65 border border-slate-800/80 rounded-xl p-3 flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-full border border-slate-700 bg-slate-900 flex items-center justify-center overflow-hidden">
              {customImage ? (
                <img src={customImage} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div
                  className="w-5 h-5 rounded"
                  style={{ backgroundColor: selectedColor }}
                />
              )}
            </div>
            <div>
              <div className="text-xs font-sans font-medium text-white flex items-center gap-1">
                Active Aspect
              </div>
              <div className="text-[9px] font-mono text-slate-400 uppercase">
                {customImage ? 'Loaded Custom Spritesheet' : `${selectedPreset} in ${selectedColor}`}
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Cute Companion Pets Selector Segment */}
      <div className="border-t border-slate-800 pt-4">
        <label className="text-xs font-mono font-medium text-slate-400 uppercase tracking-widest flex items-center gap-1.5 mb-3">
          ❤️ Activate Pet Companion
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {PETS_LIST.map((pet) => (
            <button
              key={pet.id}
              onClick={() => onSelectPet && onSelectPet(pet.id as any)}
              className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center cursor-pointer select-none ${
                activePet === pet.id
                  ? 'bg-rose-500/10 border-rose-500 text-white'
                  : 'bg-slate-950/30 border-slate-800/80 hover:border-slate-700 text-slate-400'
              }`}
            >
              <span className="text-2xl mb-1">{pet.emoji}</span>
              <span className="text-[11px] font-sans font-medium">{pet.name}</span>
              <span className="text-[8px] text-slate-500 mt-0.5 line-clamp-1">{pet.desc}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800 text-[10px] text-slate-400 flex items-start gap-2">
        <Shield className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
        <div>
          <span className="text-sky-300 font-medium">Developer Tip:</span> If you upload an image, the game's high-speed Canvas engine dynamically caches and wraps it in a protective frame matching your selected accent color, providing responsive animation frames as you walk!
        </div>
      </div>
    </div>
  );
}
