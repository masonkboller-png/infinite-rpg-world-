/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { Tile, Position, PlayerStats, Monster, NPC, Particle, FloatingText, BiomeType } from '../types';
import { MAP_SIZE } from '../utils/worldGenerator';

// Retro Synth Audio Engine
const playRetroSound = (type: 'walk' | 'hit' | 'player_hit' | 'coin' | 'levelup' | 'potion' | 'stairs') => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'walk') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, audioCtx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.08);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.08);
    } else if (type === 'hit') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(400, audioCtx.currentTime);
      osc.frequency.linearRampToValueAtTime(80, audioCtx.currentTime + 0.18);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.18);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.18);
    } else if (type === 'player_hit') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(120, audioCtx.currentTime);
      osc.frequency.linearRampToValueAtTime(30, audioCtx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.25);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } else if (type === 'coin') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
      osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.08); // E5
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.25);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } else if (type === 'levelup') {
      // Ascending major chord
      const freqs = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      freqs.forEach((f, i) => {
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(f, audioCtx.currentTime + i * 0.08);
        o.connect(g);
        g.connect(audioCtx.destination);
        g.gain.setValueAtTime(0.15, audioCtx.currentTime + i * 0.08);
        g.gain.linearRampToValueAtTime(0, audioCtx.currentTime + i * 0.08 + 0.2);
        o.start(audioCtx.currentTime + i * 0.08);
        o.stop(audioCtx.currentTime + i * 0.08 + 0.25);
      });
    } else if (type === 'potion') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(300, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(750, audioCtx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.35);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.35);
    } else if (type === 'stairs') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(150, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(600, audioCtx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 0.4);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    }
  } catch (error) {
    // AudioContext sandbox errors handled gracefully
  }
};

interface GameCanvasProps {
  tiles: Tile[][];
  playerStats: PlayerStats;
  currentWorld: 'overworld' | 'cave';
  npcs: NPC[];
  monsters: Monster[];
  playerAvatar: string; // Base64 or preset keyword
  currentAvatarColor: string;
  onUpdateStats: (stats: PlayerStats) => void;
  onInteractNPC: (npc: NPC) => void;
  onMonsterSlay: (monsterType: string) => void;
  onEnterCave: () => void;
  onLeaveCave: () => void;
  showMessage: (text: string, type?: 'info' | 'loot' | 'combat' | 'danger') => void;
  caveSpawnPosition?: Position;
  activePet?: 'none' | 'corgi' | 'dragon' | 'slime' | 'wolf';
}

const TILE_SIZE = 40;

// Deterministic hash helpers
const hash2D = (x: number, y: number) => {
  const h = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453123;
  return h - Math.floor(h);
};

const getProceduralOverworldTile = (gx: number, gy: number): Tile => {
  const n1 = (Math.sin(gx / 12) + Math.cos(gy / 12)) * 0.5;
  const n2 = (Math.sin(gx / 5 + gy / 10) + Math.cos(gx / 8 - gy / 4)) * 0.25;
  const noise = 0.5 + n1 + n2;

  let type: BiomeType = 'meadow';
  let walkable = true;
  let obstacle: 'tree' | 'rock' | 'flower' | 'bush' | 'none' = 'none';

  // Spawn villages procedurally every 160 tiles!
  const nearestVillageX = Math.round(gx / 160) * 160 + 40;
  const nearestVillageY = Math.round(gy / 160) * 160 + 40;
  const distToVillage = Math.hypot(gx - nearestVillageX, gy - nearestVillageY);

  if (distToVillage < 10) {
    type = 'meadow';
    walkable = true;
    obstacle = 'none';
    if (Math.round(distToVillage) === 2 && hash2D(gx, gy) > 0.85) {
      obstacle = 'flower';
    }
  } else if (noise < 0.22) {
    type = 'water';
    walkable = false;
  } else if (noise > 0.6) {
    type = 'forest';
    walkable = true;
    if (hash2D(gx, gy) > 0.45) {
      obstacle = 'tree';
      walkable = false;
    } else if (hash2D(gy, gx) > 0.75) {
      obstacle = 'bush';
    }
  } else {
    type = 'meadow';
    const rand = hash2D(gx, gy);
    if (rand > 0.96) {
      obstacle = 'rock';
      walkable = false;
    } else if (rand > 0.92) {
      obstacle = 'flower';
    } else if (rand > 0.85) {
      obstacle = 'bush';
    }
  }

  return { x: gx, y: gy, type, walkable, obstacle };
};

export function GameCanvas({
  tiles,
  playerStats,
  currentWorld,
  npcs,
  monsters,
  playerAvatar,
  currentAvatarColor,
  onUpdateStats,
  onInteractNPC,
  onMonsterSlay,
  onEnterCave,
  onLeaveCave,
  showMessage,
  caveSpawnPosition,
  activePet = 'none',
}: GameCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const playerPosRef = useRef<Position>({ x: 40, y: 40 });

  // Companion pet mechanics
  const petPosRef = useRef<Position>({ x: 40, y: 40 });

  // 3D Perspective Toggle locally for self-contained elegance
  const [is3DMode, setIs3DMode] = useState<boolean>(false);

  // Pause menu capabilities
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const isPausedRef = useRef<boolean>(false);

  // Synchronize pause state with render loop ref
  useEffect(() => {
    isPausedRef.current = isPaused;
    if (isPaused) {
      keysPressedRef.current = {};
    }
  }, [isPaused]);

  // Local lists for graphics only
  const [particles, setParticles] = useState<Particle[]>([]);
  const [floats, setFloats] = useState<FloatingText[]>([]);

  // Animation frame hooks
  const activeMonstersRef = useRef<Monster[]>([]);
  const activeNpcsRef = useRef<NPC[]>([]);
  const keysPressedRef = useRef<{ [key: string]: boolean }>({});
  const lastMoveTimeRef = useRef<number>(0);
  const lastAttackTimeRef = useRef<number>(0);

  // Fetch / lookup tile from matrix bounds safely or generate procedurally
  const getTileAt = (x: number, y: number): Tile => {
    // 1. Cave: Closed structured underground of CAVE_SIZE=50
    if (currentWorld === 'cave') {
      if (y >= 0 && y < tiles.length && x >= 0 && x < tiles[0].length) {
        return tiles[y][x];
      }
      return { x, y, type: 'wall', walkable: false, obstacle: 'rock' };
    }

    // 2. Overworld: Check if within hand-crafted 80x80 starting map bounds
    if (y >= 0 && y < tiles.length && x >= 0 && x < tiles[0].length) {
      return tiles[y][x];
    }

    // 3. Procedural Infinite World Generation beyond boundaries
    return getProceduralOverworldTile(x, y);
  };

  // Convert game coordinates to onscreen viewport coordinates (taking 2D standard vs 3D Isometric into account)
  const getScreenPos = (tileX: number, tileY: number): Position => {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const viewWidth = canvasRef.current.width;
    const viewHeight = canvasRef.current.height;

    if (is3DMode) {
      const dx = tileX - playerPosRef.current.x;
      const dy = tileY - playerPosRef.current.y;
      // Rotates 45 degrees and projects isometrically
      const isoX = (dx - dy) * (TILE_SIZE * 0.8);
      const isoY = (dx + dy) * (TILE_SIZE * 0.4);
      return {
        x: viewWidth / 2 + isoX,
        y: viewHeight / 2 + isoY + 20,
      };
    } else {
      const camX = playerPosRef.current.x * TILE_SIZE - viewWidth / 2 + TILE_SIZE / 2;
      const camY = playerPosRef.current.y * TILE_SIZE - viewHeight / 2 + TILE_SIZE / 2;
      return {
        x: tileX * TILE_SIZE + TILE_SIZE / 2 - camX,
        y: tileY * TILE_SIZE + TILE_SIZE / 2 - camY,
      };
    }
  };

  // Sync monsters & npcs refs to live state
  useEffect(() => {
    activeMonstersRef.current = [...monsters];
  }, [monsters]);

  useEffect(() => {
    activeNpcsRef.current = [...npcs];
  }, [npcs]);

  const prevWorldRef = useRef<'overworld' | 'cave' | null>(null);

  // Sync player position ref & fix stuck coordinate loop!
  useEffect(() => {
    if (prevWorldRef.current === null) {
      // On initial mount, place player at start village center or cave spawn
      if (currentWorld === 'cave') {
        playerPosRef.current = caveSpawnPosition || { x: 5, y: 5 };
      } else {
        playerPosRef.current = { x: 40, y: 40 }; // Starting village
      }
    } else if (prevWorldRef.current !== currentWorld) {
      // On actual world transition
      if (currentWorld === 'cave') {
        playerPosRef.current = caveSpawnPosition || { x: 5, y: 5 };
      } else {
        playerPosRef.current = { x: 62, y: 18 }; // Northeast cave entrance
      }
    }
    prevWorldRef.current = currentWorld;
    petPosRef.current = { ...playerPosRef.current };
  }, [currentWorld, caveSpawnPosition]);

  // Pre-load custom base64 image if any
  const avatarImageRef = useRef<HTMLImageElement | null>(null);
  useEffect(() => {
    if (playerAvatar.startsWith('data:image/')) {
      const img = new Image();
      img.src = playerAvatar;
      img.onload = () => {
        avatarImageRef.current = img;
      };
    } else {
      avatarImageRef.current = null;
    }
  }, [playerAvatar]);

  // Handle D-Pad/Controls overlay triggers (useful on touchscreens/Vivobooks)
  const handleDirectionMove = (dx: number, dy: number) => {
    const nextX = playerPosRef.current.x + dx;
    const nextY = playerPosRef.current.y + dy;

    const tile = getTileAt(nextX, nextY);
    if (tile.walkable) {
      playerPosRef.current = { x: nextX, y: nextY };
      playRetroSound('walk');

      const sPos = getScreenPos(nextX, nextY);
      spawnParticles(sPos.x, sPos.y, '#475569', 3);

      // Check stair interactions or items
      checkTileInteractions(tile);
    }
  };

  const checkTileInteractions = (tile: Tile) => {
    if (tile.type === 'stairs_down' && currentWorld === 'overworld') {
      playRetroSound('stairs');
      onEnterCave();
      showMessage('🧙 You descended into the Ancient Caves! Beware of Skeletons.', 'danger');
    } else if (tile.type === 'stairs_up' && currentWorld === 'cave') {
      playRetroSound('stairs');
      onLeaveCave();
      showMessage('☀️ Emerged back to the sunny meadows of Overworld!', 'info');
    } else if (tile.type === 'chest') {
      // Open chest
      tile.type = currentWorld === 'cave' ? 'cave' : 'meadow';
      tile.obstacle = 'none';
      playRetroSound('coin');

      const lootGold = 100;
      const updatedXp = playerStats.xp + 50;
      const updatedGold = playerStats.gold + lootGold;

      onUpdateStats({
        ...playerStats,
        gold: updatedGold,
        xp: updatedXp >= playerStats.maxXp ? 0 : updatedXp,
        level: updatedXp >= playerStats.maxXp ? playerStats.level + 1 : playerStats.level,
        maxHp: updatedXp >= playerStats.maxXp ? playerStats.maxHp + 15 : playerStats.maxHp,
        hp: updatedXp >= playerStats.maxXp ? playerStats.maxHp + 15 : playerStats.hp,
      });

      const sPos = getScreenPos(tile.x, tile.y);
      spawnFloats(sPos.x, sPos.y, `+${lootGold} GOLD & XP!`, '#fbbf24');
      showMessage('🎁 Found Chest! Looted +100 Gold and +50 XP bonus.', 'loot');
    } else if (tile.obstacle === 'flower' && currentWorld === 'cave') {
      // Glow mushroom restoration
      tile.obstacle = 'none';
      playRetroSound('potion');
      const updatedMp = Math.min(playerStats.maxMp, playerStats.mp + 20);
      onUpdateStats({ ...playerStats, mp: updatedMp });
      const sPos = getScreenPos(tile.x, tile.y);
      spawnFloats(sPos.x, sPos.y, '+20 Mana', '#38bdf8');
    } else if (tile.obstacle === 'rock' && currentWorld === 'cave' && Math.random() > 0.6) {
      // Crimson crystal restoration
      tile.obstacle = 'none';
      playRetroSound('potion');
      const updatedHp = Math.min(playerStats.maxHp, playerStats.hp + 25);
      onUpdateStats({ ...playerStats, hp: updatedHp });
      const sPos = getScreenPos(tile.x, tile.y);
      spawnFloats(sPos.x, sPos.y, '+25 HP', '#f43f5e');
    }
  };

  const handleManualAttack = () => {
    const now = Date.now();
    if (now - lastAttackTimeRef.current < 350) return; // Attack cooldown (350ms)
    lastAttackTimeRef.current = now;

    playRetroSound('hit');
    const px = playerPosRef.current.x;
    const py = playerPosRef.current.y;

    const pScreen = getScreenPos(px, py);
    spawnParticles(pScreen.x, pScreen.y, '#f8fafc', 8);

    // Compute damage logic on adjacent monsters
    let hitMonster = false;
    activeMonstersRef.current.forEach((enemy) => {
      const distance = Math.hypot(enemy.x - px, enemy.y - py);
      if (distance < 2.2) {
        // Apply damage (Bonus from pet dragon!)
        const damage = playerStats.attack + (activePet === 'dragon' ? 4 : 0) + Math.floor(Math.random() * 5);
        enemy.hp -= damage;
        hitMonster = true;

        // Knockback monster of 1 tile if path is walkable
        const dx = Math.sign(enemy.x - px);
        const dy = Math.sign(enemy.y - py);
        const kx = Math.round(enemy.x + dx);
        const ky = Math.round(enemy.y + dy);
        if (getTileAt(kx, ky).walkable) {
          enemy.x = kx;
          enemy.y = ky;
        }

        const mScreen = getScreenPos(enemy.x, enemy.y);
        spawnFloats(mScreen.x, mScreen.y, `-${damage}`, '#f43f5e');
        spawnParticles(mScreen.x, mScreen.y, enemy.color, 10);

        if (enemy.hp <= 0) {
          // Monster Slayed
          onMonsterSlay(enemy.type);
          playRetroSound('coin');

          const earnedGold = enemy.goldReward;
          // wolf pet companion grants 20% experience bonus
          const xpBonus = Math.round(enemy.xpReward * (activePet === 'wolf' ? 1.2 : 1));
          let newXp = playerStats.xp + xpBonus;
          let levelUp = false;
          let currLevel = playerStats.level;
          let currMaxXp = playerStats.maxXp;
          let currHp = playerStats.hp;
          let currMaxHp = playerStats.maxHp;

          if (newXp >= currMaxXp) {
            levelUp = true;
            currLevel += 1;
            newXp = 0;
            currMaxXp = Math.floor(currMaxXp * 1.5);
            currMaxHp += 20;
            currHp = currMaxHp; // Fully restore HP
          }

          onUpdateStats({
            ...playerStats,
            xp: newXp,
            level: currLevel,
            maxXp: currMaxXp,
            gold: playerStats.gold + earnedGold,
            hp: currHp,
            maxHp: currMaxHp,
          });

          if (levelUp) {
            playRetroSound('levelup');
            showMessage(`🎉 LEVEL UP! You became Level ${currLevel}!`, 'info');
            spawnFloats(pScreen.x, pScreen.y - 20, 'LEVEL UP!', '#a855f7');
          } else {
            showMessage(`⚔️ Defeated ${enemy.name}! Gained +${earnedGold} Gold and +${xpBonus} XP.`, 'loot');
          }
        }
      }
    });

    if (!hitMonster) {
      // Check NPC dialog activation if adjacent to an NPC
      let clickedNPC = false;
      activeNpcsRef.current.forEach((npc) => {
        const dist = Math.hypot(npc.x - px, npc.y - py);
        if (dist < 1.7) {
          clickedNPC = true;
          onInteractNPC(npc);
        }
      });
    }
  };

  // Setup Keyboard Gameloop Events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        setIsPaused((prev) => !prev);
        return;
      }

      if (isPausedRef.current) return;

      keysPressedRef.current[e.key.toLowerCase()] = true;
      if (e.key === ' ') {
        e.preventDefault();
        handleManualAttack();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Escape') return;
      keysPressedRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [playerStats, tiles, npcs, monsters, activePet, isPaused]);

  // Particle Generators (Screen coordinates based)
  const spawnParticles = (x: number, y: number, color: string, count: number) => {
    const list: Particle[] = [];
    for (let i = 0; i < count; i++) {
      list.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5,
        color,
        alpha: 1,
        size: Math.random() * 4 + 2,
        decay: 0.02 + Math.random() * 0.02,
      });
    }
    setParticles((prev) => [...prev, ...list]);
  };

  const spawnFloats = (x: number, y: number, text: string, color: string) => {
    const id = Math.random().toString();
    setFloats((prev) => [...prev, { id, x, y, text, color, alpha: 1, vy: -1.5 }]);
  };

  // Main Canvas Rendering Gameloop (60 FPS)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let localFrameId: number;

    const tick = () => {
      const now = Date.now();
      const paused = isPausedRef.current;

      const px = playerPosRef.current.x;
      const py = playerPosRef.current.y;

      if (!paused) {
        // 1. Process Player continuous keyboard movement
        if (now - lastMoveTimeRef.current > 180) {
          let dx = 0;
          let dy = 0;

          if (keysPressedRef.current['w'] || keysPressedRef.current['arrowup']) dy = -1;
          else if (keysPressedRef.current['s'] || keysPressedRef.current['arrowdown']) dy = 1;
          else if (keysPressedRef.current['a'] || keysPressedRef.current['arrowleft']) dx = -1;
          else if (keysPressedRef.current['d'] || keysPressedRef.current['arrowright']) dx = 1;

          if (dx !== 0 || dy !== 0) {
            handleDirectionMove(dx, dy);
            lastMoveTimeRef.current = now;
          }
        }

        // 2. Continuous Companion Pet tracking behind player
        if (activePet && activePet !== 'none') {
          const petDist = Math.hypot(px - petPosRef.current.x, py - petPosRef.current.y);
          if (petDist > 1.2) {
            const angle = Math.atan2(py - petPosRef.current.y, px - petPosRef.current.x);
            petPosRef.current.x += Math.cos(angle) * 0.07;
            petPosRef.current.y += Math.sin(angle) * 0.07;
          }
        }

        // 3. Infinite Overworld Procedural Monster Spawner
        if (currentWorld === 'overworld') {
          const monstersNearby = activeMonstersRef.current.filter((m) => Math.hypot(m.x - px, m.y - py) < 14);
          if (monstersNearby.length < 3 && Math.random() > 0.985) {
            // Spawn Slime or Wolf around the player at a walkable spot
            const angle = Math.random() * Math.PI * 2;
            const rDist = 6 + Math.random() * 5;
            const sx = Math.round(px + Math.cos(angle) * rDist);
            const sy = Math.round(py + Math.sin(angle) * rDist);
            const trialTile = getTileAt(sx, sy);

            if (trialTile.walkable) {
              const isForest = trialTile.type === 'forest';
              const mType = Math.random() > (isForest ? 0.35 : 0.82) ? 'wolf' : 'slime';
              const mName = mType === 'wolf' ? 'Wild Wolf' : 'Meadow Slime';
              const mColor = mType === 'wolf' ? '#94a3b8' : '#34d399';
              const mSize = mType === 'wolf' ? 14 : 10;
              const hpVal = mType === 'wolf' ? 30 : 15;
              const attVal = mType === 'wolf' ? 4 : 2;

              activeMonstersRef.current.push({
                id: `proc_m_${Date.now()}_${Math.random()}`,
                name: mName,
                type: mType,
                x: sx,
                y: sy,
                hp: hpVal,
                maxHp: hpVal,
                attack: attVal,
                speed: mType === 'wolf' ? 2 : 1,
                xpReward: mType === 'wolf' ? 25 : 10,
                goldReward: mType === 'wolf' ? 12 : 5,
                color: mColor,
                size: mSize,
                isAggressive: true,
                state: 'idle',
                startX: sx,
                startY: sy,
                lastAttackTime: 0,
              });
            }
          }
        }

        // 4. Process Monsters AI chasing
        activeMonstersRef.current.forEach((monster) => {
          const mx = monster.x;
          const my = monster.y;
          const distanceToPlayer = Math.hypot(px - mx, py - my);

          if (monster.isAggressive && distanceToPlayer < 7 && distanceToPlayer > 1) {
            monster.state = 'chasing';
            
            if (now % 3 === 0 && Math.random() > 0.7) {
              const dx = Math.sign(px - mx);
              const dy = Math.sign(py - my);
              const stepX = mx + (Math.abs(dx) >= Math.abs(dy) ? dx : 0);
              const stepY = my + (Math.abs(dy) > Math.abs(dx) ? dy : 0);

              if (getTileAt(stepX, stepY).walkable) {
                monster.x = stepX;
                monster.y = stepY;
              }
            }
          } else if (distanceToPlayer <= 1.2) {
            // Melee attack player
            if (now - monster.lastAttackTime > 1500) {
              monster.lastAttackTime = now;
              playRetroSound('player_hit');

              const rollDmg = Math.max(1, monster.attack + Math.floor(Math.random() * 3));
              const nextHp = Math.max(0, playerStats.hp - rollDmg);

              onUpdateStats({ ...playerStats, hp: nextHp });

              const pScreen = getScreenPos(px, py);
              spawnFloats(pScreen.x, pScreen.y, `-${rollDmg} HP`, '#ef4444');
              spawnParticles(pScreen.x, pScreen.y, '#f43f5e', 8);

              if (nextHp <= 0) {
                showMessage('💀 YOU DIED! Resurrected at starting village.', 'danger');
                playerPosRef.current = { x: 40, y: 40 }; // Start village center
                petPosRef.current = { x: 40, y: 40 };
                onUpdateStats({ ...playerStats, hp: playerStats.maxHp, gold: Math.max(0, playerStats.gold - 20) });
              }
            }
          } else {
            // Wander idle
            if (Math.random() > 0.99) {
              const roamX = Math.round(mx + (Math.random() > 0.5 ? 1 : -1));
              const roamY = Math.round(my + (Math.random() > 0.5 ? 1 : -1));
              if (getTileAt(roamX, roamY).walkable) {
                monster.x = roamX;
                monster.y = roamY;
              }
            }
          }
        });
      }

      // 5. Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.save();

      const viewWidth = canvas.width;
      const viewHeight = canvas.height;

      if (is3DMode) {
        // --- 3D ISOMETRIC VIEWPORT RENDERER ---
        const drawRadius = 10;
        const startTileX = Math.round(px) - drawRadius;
        const endTileX = Math.round(px) + drawRadius;
        const startTileY = Math.round(py) - drawRadius;
        const endTileY = Math.round(py) + drawRadius;

        for (let y = startTileY; y <= endTileY; y++) {
          for (let x = startTileX; x <= endTileX; x++) {
            const tile = getTileAt(x, y);
            const dx = x - px;
            const dy = y - py;

            const isoX = (dx - dy) * (TILE_SIZE * 0.8);
            const isoY = (dx + dy) * (TILE_SIZE * 0.4);

            const sx = viewWidth / 2 + isoX;
            const sy = viewHeight / 2 + isoY + 20;

            if (sx > -TILE_SIZE * 1.5 && sx < viewWidth + TILE_SIZE * 1.5 && sy > -TILE_SIZE * 1.5 && sy < viewHeight + TILE_SIZE * 1.5) {
              
              // Draw ground diamond tile
              const w = TILE_SIZE * 0.8;
              const h = TILE_SIZE * 0.4;

              ctx.beginPath();
              ctx.moveTo(sx, sy - h);
              ctx.lineTo(sx + w, sy);
              ctx.lineTo(sx, sy + h);
              ctx.lineTo(sx - w, sy);
              ctx.closePath();

              if (tile.type === 'water') {
                ctx.fillStyle = '#0f172a';
              } else if (tile.type === 'forest') {
                ctx.fillStyle = '#064e3b';
              } else if (tile.type === 'cave') {
                ctx.fillStyle = '#1e293b';
              } else if (tile.type === 'stairs_down') {
                ctx.fillStyle = '#475569';
              } else if (tile.type === 'stairs_up') {
                ctx.fillStyle = '#334155';
              } else if (tile.type === 'chest') {
                ctx.fillStyle = '#f59e0b';
              } else {
                ctx.fillStyle = '#14532d'; // meadows
              }
              ctx.fill();

              ctx.strokeStyle = tile.type === 'water' ? '#1e293b' : tile.type === 'cave' ? '#111827' : '#15803d';
              ctx.stroke();

              // Details inside diamond ground
              if (tile.type === 'stairs_down') {
                ctx.fillStyle = '#0f172a';
                ctx.beginPath();
                ctx.ellipse(sx, sy, 8, 4, 0, 0, Math.PI * 2);
                ctx.fill();
              } else if (tile.type === 'stairs_up') {
                ctx.fillStyle = '#fbbf24';
                ctx.beginPath();
                ctx.ellipse(sx, sy, 4, 2, 0, 0, Math.PI * 2);
                ctx.fill();
              }

              // Draw height blocks and volumetric walls / items
              if (tile.type === 'wall') {
                const H = 22; // Block height
                // Top
                ctx.beginPath();
                ctx.moveTo(sx, sy - h - H);
                ctx.lineTo(sx + w, sy - H);
                ctx.lineTo(sx, sy + h - H);
                ctx.lineTo(sx - w, sy - H);
                ctx.closePath();
                ctx.fillStyle = '#334155';
                ctx.fill();
                ctx.strokeStyle = '#475569';
                ctx.stroke();

                // Left column vertical
                ctx.beginPath();
                ctx.moveTo(sx - w, sy);
                ctx.lineTo(sx - w, sy - H);
                ctx.lineTo(sx, sy + h - H);
                ctx.lineTo(sx, sy + h);
                ctx.closePath();
                ctx.fillStyle = '#1e293b';
                ctx.fill();

                // Right column vertical
                ctx.beginPath();
                ctx.moveTo(sx, sy + h);
                ctx.lineTo(sx, sy + h - H);
                ctx.lineTo(sx + w, sy - H);
                ctx.lineTo(sx + w, sy);
                ctx.closePath();
                ctx.fillStyle = '#0f172a';
                ctx.fill();
              } else if (tile.obstacle === 'tree') {
                // Trunk
                ctx.fillStyle = '#78350f';
                ctx.fillRect(sx - 3, sy - 8, 6, 10);
                // Pine leaves
                ctx.fillStyle = '#047857';
                ctx.beginPath();
                ctx.moveTo(sx, sy - 32);
                ctx.lineTo(sx - 9, sy - 8);
                ctx.lineTo(sx + 9, sy - 8);
                ctx.closePath();
                ctx.fill();
              } else if (tile.obstacle === 'rock') {
                ctx.fillStyle = currentWorld === 'cave' ? '#f43f5e' : '#475569';
                ctx.beginPath();
                ctx.moveTo(sx, sy - 12);
                ctx.lineTo(sx - 6, sy);
                ctx.lineTo(sx + 6, sy);
                ctx.closePath();
                ctx.fill();
              } else if (tile.obstacle === 'bush') {
                ctx.fillStyle = '#065f46';
                ctx.beginPath();
                ctx.ellipse(sx, sy - 3, 9, 7, 0, 0, Math.PI * 2);
                ctx.fill();
              } else if (tile.obstacle === 'flower') {
                ctx.fillStyle = currentWorld === 'cave' ? '#0ea5e9' : '#ef4444';
                ctx.beginPath();
                ctx.arc(sx, sy - 2, 2.5, 0, Math.PI * 2);
                ctx.fill();
              } else if (tile.type === 'chest') {
                const CH = 10;
                ctx.beginPath();
                ctx.rect(sx - 7, sy - CH - 3, 14, CH);
                ctx.fillStyle = '#f59e0b';
                ctx.fill();
                ctx.strokeStyle = '#000';
                ctx.stroke();
                ctx.fillStyle = '#fbbf24';
                ctx.fillRect(sx - 1.5, sy - CH, 3, 3);
              }

              // Draw NPCs standing on this tile coordinates
              activeNpcsRef.current.forEach((npc) => {
                if (Math.round(npc.x) === x && Math.round(npc.y) === y) {
                  ctx.fillStyle = npc.color;
                  ctx.beginPath();
                  ctx.arc(sx, sy - 12, 8, 0, Math.PI * 2);
                  ctx.fill();

                  ctx.fillStyle = '#ffffff';
                  ctx.beginPath();
                  ctx.moveTo(sx - 3, sy - 18);
                  ctx.lineTo(sx + 3, sy - 18);
                  ctx.lineTo(sx, sy - 24);
                  ctx.closePath();
                  ctx.fill();

                  ctx.fillStyle = '#ffffff';
                  ctx.font = 'bold 7px monospace';
                  ctx.textAlign = 'center';
                  ctx.fillText(npc.name, sx, sy - 22);
                }
              });

              // Draw Monsters standing on this tile coordinates
              activeMonstersRef.current.forEach((monster) => {
                if (Math.round(monster.x) === x && Math.round(monster.y) === y) {
                  ctx.save();
                  ctx.translate(sx, sy - 6);
                  const scaleY = monster.type === 'slide' ? 1 + Math.sin(now / 150) * 0.12 : 1;
                  ctx.scale(1, scaleY);
                  ctx.fillStyle = monster.color;
                  ctx.beginPath();
                  ctx.arc(0, 0, monster.size * 0.7, 0, Math.PI * 2);
                  ctx.fill();
                  ctx.restore();

                  ctx.fillStyle = '#000';
                  ctx.fillRect(sx - 10, sy - 18, 20, 2.5);
                  ctx.fillStyle = '#ef4444';
                  ctx.fillRect(sx - 10, sy - 18, 20 * (monster.hp / monster.maxHp), 2.5);

                  ctx.fillStyle = '#ffffff';
                  ctx.font = '7px monospace';
                  ctx.textAlign = 'center';
                  ctx.fillText(monster.name, sx, sy - 21);
                }
              });

              // Draw Player character
              if (Math.round(px) === x && Math.round(py) === y) {
                ctx.save();
                const bob = Math.sin(now / 120) * 1.5;

                if (avatarImageRef.current) {
                  ctx.strokeStyle = currentAvatarColor;
                  ctx.lineWidth = 2;
                  ctx.fillStyle = '#1e293b';

                  ctx.beginPath();
                  ctx.arc(sx, sy - 12 + bob, 11, 0, Math.PI * 2);
                  ctx.fill();
                  ctx.stroke();

                  ctx.clip();
                  ctx.drawImage(avatarImageRef.current, sx - 11, sy - 23 + bob, 22, 22);
                } else {
                  ctx.fillStyle = currentAvatarColor;
                  ctx.beginPath();
                  ctx.arc(sx, sy - 12 + bob, 10, 0, Math.PI * 2);
                  ctx.fill();

                  ctx.fillStyle = '#ffffff';
                  ctx.fillRect(sx - 3, sy - 13 + bob, 2, 3);
                  ctx.fillRect(sx + 1, sy - 13 + bob, 2, 3);
                }
                ctx.restore();
              }

              // Draw Cute Pet following character
              if (activePet && activePet !== 'none') {
                if (Math.round(petPosRef.current.x) === x && Math.round(petPosRef.current.y) === y) {
                  const bob = Math.sin(now / 100) * 2.5;
                  ctx.save();
                  ctx.translate(sx + 12, sy - 9 + bob);

                  if (activePet === 'corgi') {
                    ctx.fillStyle = '#f59e0b';
                    ctx.fillRect(-4, -2, 8, 4);
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(-1, 0, 4, 2);
                    ctx.fillStyle = '#f59e0b';
                    ctx.fillRect(2, -5, 3, 3);
                  } else if (activePet === 'dragon') {
                    ctx.fillStyle = '#ef4444';
                    ctx.fillRect(-3, -3, 6, 6);
                    ctx.fillStyle = '#fbbf24';
                    ctx.fillRect(-5, -4, 2, 2);
                    ctx.fillRect(3, -4, 2, 2);
                  } else if (activePet === 'slime') {
                    ctx.fillStyle = '#22c55e';
                    ctx.beginPath();
                    ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
                    ctx.fill();
                  } else if (activePet === 'wolf') {
                    ctx.fillStyle = '#64748b';
                    ctx.fillRect(-4, -2, 8, 4);
                    ctx.fillRect(1, -5, 3, 3);
                  }
                  ctx.restore();
                }
              }

            }
          }
        }
      } else {
        // --- STANDARD 2D TOP-DOWN CANVAS VIEW ---
        const camX = Math.round(px * TILE_SIZE - viewWidth / 2 + TILE_SIZE / 2);
        const camY = Math.round(py * TILE_SIZE - viewHeight / 2 + TILE_SIZE / 2);

        const startTileX = Math.floor(camX / TILE_SIZE) - 1;
        const endTileX = Math.floor((camX + viewWidth) / TILE_SIZE) + 1;
        const startTileY = Math.floor(camY / TILE_SIZE) - 1;
        const endTileY = Math.floor((camY + viewHeight) / TILE_SIZE) + 1;

        for (let y = startTileY; y <= endTileY; y++) {
          for (let x = startTileX; x <= endTileX; x++) {
            const tile = getTileAt(x, y);
            const rx = x * TILE_SIZE - camX;
            const ry = y * TILE_SIZE - camY;

            if (tile.type === 'water') {
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
              ctx.strokeStyle = '#1e293b';
              ctx.lineWidth = 1;
              ctx.strokeRect(rx, ry, TILE_SIZE, TILE_SIZE);
              
              if ((x + y) % 5 === 0) {
                ctx.strokeStyle = '#0284c7';
                ctx.beginPath();
                ctx.moveTo(rx + 6, ry + 15);
                ctx.lineTo(rx + 20, ry + 15);
                ctx.stroke();
              }
            } else if (tile.type === 'forest') {
              ctx.fillStyle = '#064e3b';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
            } else if (tile.type === 'cave') {
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
            } else if (tile.type === 'wall') {
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
              ctx.fillStyle = '#1e293b';
              ctx.fillRect(rx + 2, ry + 2, TILE_SIZE - 4, TILE_SIZE - 4);
            } else if (tile.type === 'stairs_down') {
              ctx.fillStyle = '#475569';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
              ctx.fillStyle = '#0f172a';
              ctx.beginPath();
              ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2, 14, 0, Math.PI * 2);
              ctx.fill();
              ctx.strokeStyle = '#fbbf24';
              ctx.stroke();
            } else if (tile.type === 'stairs_up') {
              ctx.fillStyle = '#334155';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
              ctx.fillStyle = '#fbbf24';
              ctx.beginPath();
              ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2, 6, 0, Math.PI * 2);
              ctx.fill();
            } else if (tile.type === 'chest') {
              ctx.fillStyle = '#14532d';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
            } else {
              ctx.fillStyle = '#14532d';
              ctx.fillRect(rx, ry, TILE_SIZE, TILE_SIZE);
              ctx.strokeStyle = '#15803d';
              ctx.strokeRect(rx, ry, TILE_SIZE, TILE_SIZE);
            }

            // Obstacles
            if (tile.obstacle === 'tree') {
              ctx.fillStyle = '#78350f';
              ctx.fillRect(rx + TILE_SIZE / 2 - 3, ry + TILE_SIZE - 12, 6, 12);
              ctx.fillStyle = '#047857';
              ctx.beginPath();
              ctx.moveTo(rx + TILE_SIZE / 2, ry + 4);
              ctx.lineTo(rx + 8, ry + TILE_SIZE - 10);
              ctx.lineTo(rx + TILE_SIZE - 8, ry + TILE_SIZE - 10);
              ctx.closePath();
              ctx.fill();
            } else if (tile.obstacle === 'bush') {
              ctx.fillStyle = '#065f46';
              ctx.beginPath();
              ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2 + 4, 12, 0, Math.PI * 2);
              ctx.fill();
            } else if (tile.obstacle === 'flower') {
              if (currentWorld === 'cave') {
                ctx.fillStyle = '#0ea5e9';
                ctx.beginPath();
                ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2, 6, Math.PI, 0);
                ctx.closePath();
                ctx.fill();
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(rx + TILE_SIZE / 2 - 2, ry + TILE_SIZE / 2, 4, 8);
              } else {
                ctx.fillStyle = '#ef4444';
                ctx.beginPath();
                ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2, 4, 0, Math.PI * 2);
                ctx.fill();
              }
            } else if (tile.obstacle === 'rock') {
              if (currentWorld === 'cave') {
                ctx.fillStyle = '#f43f5e';
                ctx.beginPath();
                ctx.moveTo(rx + TILE_SIZE / 2, ry + 6);
                ctx.lineTo(rx + 8, ry + TILE_SIZE - 8);
                ctx.lineTo(rx + TILE_SIZE - 8, ry + TILE_SIZE - 8);
                ctx.closePath();
                ctx.fill();
              } else {
                ctx.fillStyle = '#475569';
                ctx.beginPath();
                ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2 + 6, 10, 0, Math.PI * 2);
                ctx.fill();
              }
            } else if (tile.type === 'chest') {
              ctx.fillStyle = '#f59e0b';
              ctx.fillRect(rx + 8, ry + 10, TILE_SIZE - 16, TILE_SIZE - 16);
              ctx.strokeStyle = '#000';
              ctx.strokeRect(rx + 8, ry + 10, TILE_SIZE - 16, TILE_SIZE - 16);
              ctx.fillStyle = '#000';
              ctx.fillRect(rx + TILE_SIZE / 2 - 2, ry + 16, 4, 6);
            }
          }
        }

        // Render NPCs 2D
        activeNpcsRef.current.forEach((npc) => {
          const rx = npc.x * TILE_SIZE - camX;
          const ry = npc.y * TILE_SIZE - camY;

          if (rx > -TILE_SIZE && rx < viewWidth && ry > -TILE_SIZE && ry < viewHeight) {
            ctx.fillStyle = npc.color;
            ctx.beginPath();
            ctx.arc(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2, 13, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.moveTo(rx + TILE_SIZE / 2 - 4, ry + 12);
            ctx.lineTo(rx + TILE_SIZE / 2 + 4, ry + 12);
            ctx.lineTo(rx + TILE_SIZE / 2, ry + 6);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 9px monospace';
            ctx.textAlign = 'center';
            ctx.fillText(npc.name, rx + TILE_SIZE / 2, ry - 6);
          }
        });

        // Render Monsters 2D
        activeMonstersRef.current.forEach((monster) => {
          const rx = monster.x * TILE_SIZE - camX;
          const ry = monster.y * TILE_SIZE - camY;

          if (rx > -TILE_SIZE && rx < viewWidth && ry > -TILE_SIZE && ry < viewHeight) {
            const scaleY = monster.type === 'slime' ? 1 + Math.sin(now / 150) * 0.15 : 1;
            const scaleX = monster.type === 'slime' ? 1 - Math.sin(now / 150) * 0.15 : 1;

            ctx.save();
            ctx.translate(rx + TILE_SIZE / 2, ry + TILE_SIZE / 2);
            ctx.scale(scaleX, scaleY);
            ctx.fillStyle = monster.color;
            ctx.beginPath();
            ctx.arc(0, 0, monster.size, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#000';
            if (monster.type === 'slime') {
              ctx.fillRect(-4, -6, 2, 2);
              ctx.fillRect(2, -6, 2, 2);
            } else {
              ctx.fillRect(-3, -4, 2, 2);
              ctx.fillRect(1, -4, 2, 2);
            }
            ctx.restore();

            ctx.fillStyle = '#000000';
            ctx.fillRect(rx + 6, ry - 10, TILE_SIZE - 12, 4);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(rx + 6, ry - 10, (TILE_SIZE - 12) * (monster.hp / monster.maxHp), 4);

            ctx.fillStyle = '#f8fafc';
            ctx.font = '8px monospace';
            ctx.textAlign = 'center';
            ctx.fillText(monster.name, rx + TILE_SIZE / 2, ry - 14);
          }
        });

        // Render Player 2D
        const px2D = px * TILE_SIZE - camX;
        const py2D = py * TILE_SIZE - camY;

        ctx.save();
        if (avatarImageRef.current) {
          ctx.strokeStyle = currentAvatarColor;
          ctx.lineWidth = 3;
          ctx.fillStyle = '#1e293b';

          const pSize = 30 + Math.sin(now / 120) * 1.5;

          ctx.beginPath();
          const ax = px2D + TILE_SIZE / 2;
          const ay = py2D + TILE_SIZE / 2;
          ctx.arc(ax, ay, pSize / 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          ctx.clip();
          ctx.drawImage(avatarImageRef.current, ax - pSize / 2, ay - pSize / 2, pSize, pSize);
        } else {
          ctx.fillStyle = currentAvatarColor;
          ctx.beginPath();
          ctx.arc(px2D + TILE_SIZE / 2, py2D + TILE_SIZE / 2, 14, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(px2D + TILE_SIZE / 2 - 5, py2D + 14, 3, 4);
          ctx.fillRect(px2D + TILE_SIZE / 2 + 2, py2D + 14, 3, 4);
        }
        ctx.restore();

        // Render Cute Pet 2D
        if (activePet && activePet !== 'none') {
          const rpx2D = petPosRef.current.x * TILE_SIZE - camX;
          const rpy2D = petPosRef.current.y * TILE_SIZE - camY;
          if (rpx2D > -TILE_SIZE && rpx2D < viewWidth && rpy2D > -TILE_SIZE && rpy2D < viewHeight) {
            const bob = Math.sin(now / 100) * 3;
            ctx.save();
            ctx.translate(rpx2D + TILE_SIZE / 2, rpy2D + TILE_SIZE / 2 + bob);

            if (activePet === 'corgi') {
              ctx.fillStyle = '#f59e0b';
              ctx.fillRect(-6, -2, 12, 6);
              ctx.fillStyle = '#ffffff';
              ctx.fillRect(-2, 1, 6, 3);
              ctx.fillStyle = '#f59e0b';
              ctx.fillRect(4, -8, 4, 6);
            } else if (activePet === 'dragon') {
              ctx.fillStyle = '#ef4444';
              ctx.fillRect(-5, -5, 10, 10);
              ctx.fillStyle = '#fbbf24';
              ctx.fillRect(-9, -7, 4, 4);
              ctx.fillRect(5, -7, 4, 4);
            } else if (activePet === 'slime') {
              ctx.fillStyle = '#22c55e';
              ctx.beginPath();
              ctx.arc(0, 0, 5.5, 0, Math.PI * 2);
              ctx.fill();
            } else if (activePet === 'wolf') {
              ctx.fillStyle = '#64748b';
              ctx.fillRect(-6, -3, 12, 7);
              ctx.fillRect(2, -8, 5, 5);
            }
            ctx.restore();
          }
        }
      }

      ctx.restore(); // end canvas draw state

      // 4. Update particles list in continuous rendering frames
      setParticles((prevParticles) => {
        const keeps: Particle[] = [];
        prevParticles.forEach((p) => {
          if (!paused) {
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= p.decay;
          }
          if (p.alpha > 0) {
            ctx.save();
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p.color;
            ctx.fillRect(p.x, p.y, p.size, p.size);
            ctx.restore();
            keeps.push(p);
          }
        });
        return keeps;
      });

      // 5. Update floating damage points text
      setFloats((prevFloats) => {
        const keeps: FloatingText[] = [];
        prevFloats.forEach((f) => {
          if (!paused) {
            f.y += f.vy;
            f.alpha -= 0.02;
          }
          if (f.alpha > 0) {
            ctx.save();
            ctx.globalAlpha = f.alpha;
            ctx.fillStyle = f.color;
            ctx.font = 'bold 12px "JetBrains Mono", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(f.text, f.x, f.y);
            ctx.restore();
            keeps.push(f);
          }
        });
        return keeps;
      });

      localFrameId = requestAnimationFrame(tick);
    };

    localFrameId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(localFrameId);
    };
  }, [tiles, playerStats, npcs, monsters, playerAvatar, currentAvatarColor, is3DMode, activePet]);

  // Clean resize helper (ensures Canvas fits dynamically inside container width)
  useEffect(() => {
    const handleResize = () => {
      const parent = containerRef.current;
      const canvas = canvasRef.current;
      if (!parent || !canvas) return;

      canvas.width = Math.min(640, parent.clientWidth);
      canvas.height = 400;
    };

    handleResize();

    const observer = new ResizeObserver(handleResize);
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div className="flex flex-col items-center w-full">
      {/* Game Stage wrapper */}
      <div
        ref={containerRef}
        className="w-full flex justify-center bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden p-4 relative min-h-[432px]"
      >
        {/* Toggle 3D button overlay */}
        <div className="absolute top-4 left-4 z-10 flex gap-2">
          <button
            onClick={() => {
              setIs3DMode(!is3DMode);
              showMessage(is3DMode ? '📺 Switched to 2D Top-down layout!' : '🔴 Isometric 3D rendering activated!', 'info');
            }}
            className="bg-slate-900/80 hover:bg-slate-800 backdrop-blur border border-slate-700/50 text-white font-mono text-[10px] font-bold py-1.5 px-3 rounded-xl shadow cursor-pointer active:scale-95 transition-all select-none flex items-center gap-1.5"
          >
            {is3DMode ? '📺 STANDARD 2D' : '📐 ISOMETRIC 3D'}
          </button>
        </div>

        {/* Toggle Pause button overlay */}
        <div className="absolute top-4 right-4 z-10 flex gap-2">
          <button
            onClick={() => {
              setIsPaused((p) => !p);
            }}
            className="bg-slate-900/80 hover:bg-slate-800 backdrop-blur border border-slate-700/50 text-white font-mono text-[10px] font-bold py-1.5 px-3 rounded-xl shadow cursor-pointer active:scale-95 transition-all select-none flex items-center gap-1.5"
          >
            ⏸️ {isPaused ? 'RESUME' : 'PAUSE (ESC)'}
          </button>
        </div>

        <canvas
          ref={canvasRef}
          id="retro-game"
          className="rounded-2xl cursor-crosshair border border-slate-900 shadow-inner"
        />

        {/* Ambient overlay when playing dungeon levels */}
        {currentWorld === 'cave' && (
          <div className="absolute inset-0 border border-indigo-900/30 ring-[35px] ring-black/45 pointer-events-none rounded-3xl" />
        )}

        {/* Beautiful Pause Menu Modal Backdrop overlay */}
        {isPaused && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-4 text-center select-none">
            <div className="max-w-xs w-full bg-slate-900 border-2 border-indigo-500/30 rounded-3xl p-5 shadow-2xl flex flex-col gap-4 relative animate-in fade-in zoom-in-95 duration-150">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-indigo-600 text-[9px] font-mono font-bold text-white uppercase px-3 py-0.5 rounded-full border border-indigo-400 shadow-lg tracking-widest">
                GAME SUSPENDED
              </div>

              <div className="space-y-1 mt-2">
                <h3 className="text-sm font-sans font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
                  <span>⏸️</span> ADVENTURE PAUSED
                </h3>
                <p className="text-[10px] text-slate-400 font-mono">
                  Press <kbd className="bg-slate-800 text-slate-250 px-1 py-0.5 rounded border border-slate-700 text-[9px]">ESC</kbd> to resume
                </p>
              </div>

              {/* Player Stats Snapshot */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 text-left space-y-2">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-1.5">
                  <div 
                    className="w-7 h-7 rounded-full border flex items-center justify-center text-xs shrink-0" 
                    style={{ 
                      borderColor: currentAvatarColor, 
                      backgroundColor: `${currentAvatarColor}15` 
                    }}
                  >
                    {playerAvatar && playerAvatar.length > 30 ? (
                      <img 
                        src={playerAvatar} 
                        alt="Hero" 
                        className="w-full h-full rounded-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <span>🛡️</span>
                    )}
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-white font-sans flex items-center gap-1">
                      Meadowvale Hero
                      <span className="text-[8px] font-mono text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-1 rounded">
                        Lvl {playerStats.level}
                      </span>
                    </div>
                    <div className="text-[9px] text-slate-500 font-mono uppercase">
                      World: <span className="text-indigo-400 font-semibold">{currentWorld}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px] font-mono">
                  <div className="text-slate-400">
                    ❤️ HP: <span className="text-red-400 font-bold">{playerStats.hp}/{playerStats.maxHp}</span>
                  </div>
                  <div className="text-slate-400">
                    💰 Gold: <span className="text-amber-400 font-bold">{playerStats.gold}g</span>
                  </div>
                  <div className="text-slate-400">
                    ✨ XP: <span className="text-sky-400 font-bold">{playerStats.xp}</span>
                  </div>
                  <div className="text-slate-400">
                    🗡️ ATK: <span className="text-orange-400 font-bold">{playerStats.attack}</span>
                  </div>
                </div>
              </div>

              {/* Navigation Action Buttons inside the Pause Menu */}
              <div className="space-y-1.5">
                <button
                  onClick={() => setIsPaused(false)}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-[11px] py-2 rounded-xl shadow cursor-pointer transition-all active:scale-95 text-center flex items-center justify-center gap-1.5 border border-indigo-500"
                >
                  ▶️ Resume Adventure
                </button>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => {
                      onUpdateStats({ ...playerStats, hp: playerStats.maxHp });
                      showMessage('💖 Fully cured! Health is completely filled up.', 'loot');
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-350 font-mono text-[9px] py-1.5 rounded-lg border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    💖 Cure HP
                  </button>

                  <button
                    onClick={() => {
                      setIsPaused(false);
                      playerPosRef.current = { x: 40, y: 40 };
                      petPosRef.current = { x: 40, y: 40 };
                      showMessage('⛺ Teleported back to safety starting camp!', 'info');
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-350 font-mono text-[9px] py-1.5 rounded-lg border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    ⛺ Teleport
                  </button>
                </div>
              </div>

              {/* Pause Controls segment */}
              <div className="text-left border-t border-slate-800/80 pt-2.5">
                <h4 className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest mb-1">
                  Controls Quick Guide
                </h4>
                <div className="space-y-0.5 text-[9px] font-mono text-slate-400">
                  <div className="flex justify-between">
                    <span>Move Hero:</span>
                    <span className="text-slate-200">WASD / Arrow Keys</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sword Slash:</span>
                    <span className="text-slate-200">SPACEBAR</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pause Toggle:</span>
                    <span className="text-slate-200">ESC Key</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Screen action hotkeys */}
      <div className="grid grid-cols-2 gap-3 mt-4 w-full">
        <button
          onClick={handleManualAttack}
          className="col-span-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 border border-red-500/20 text-white font-sans font-bold py-3 px-6 rounded-2xl shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2 select-none active:scale-95 text-sm"
        >
          ⚔️ SWING BROADSWORD [SPACE]
        </button>

        <div className="col-span-2 grid grid-cols-3 gap-2 py-1 max-w-[240px] mx-auto w-full select-none">
          <div />
          <button
            onClick={() => handleDirectionMove(0, -1)}
            className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 border border-slate-700 p-3 rounded-xl text-center text-sm font-bold text-slate-200 cursor-pointer"
          >
            ▲
          </button>
          <div />
          <button
            onClick={() => handleDirectionMove(-1, 0)}
            className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 border border-slate-700 p-3 rounded-xl text-center text-sm font-bold text-slate-200 cursor-pointer"
          >
            ◀
          </button>
          <button
            onClick={() => handleDirectionMove(0, 1)}
            className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 border border-slate-700 p-3 rounded-xl text-center text-sm font-bold text-slate-200 cursor-pointer"
          >
            ▼
          </button>
          <button
            onClick={() => handleDirectionMove(1, 0)}
            className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 border border-slate-700 p-3 rounded-xl text-center text-sm font-bold text-slate-200 cursor-pointer"
          >
            ▶
          </button>
        </div>
      </div>
    </div>
  );
}
