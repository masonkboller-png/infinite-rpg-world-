/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Tile, BiomeType, NPC, Monster, Position } from '../types';

export const MAP_SIZE = 80; // Size of overworld map (80x80)
export const CAVE_SIZE = 50; // Size of caves map (50x50)

// Helper for generating deterministic-like variations
const hash2D = (x: number, y: number) => {
  const h = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453123;
  return h - Math.floor(h);
};

export function generateOverworld(): {
  tiles: Tile[][];
  spawnPosition: Position;
  npcs: NPC[];
  monsters: Monster[];
} {
  const tiles: Tile[][] = [];
  const npcs: NPC[] = [];
  const monsters: Monster[] = [];

  // 1. Generate base layout
  for (let y = 0; y < MAP_SIZE; y++) {
    const row: Tile[] = [];
    for (let x = 0; x < MAP_SIZE; x++) {
      // Determine biomes using trigonometric noises
      const nx = x / MAP_SIZE;
      const ny = y / MAP_SIZE;

      // Base noise functions for landmass, forest, water
      const n1 = (Math.sin(nx * 5) + Math.cos(ny * 5)) * 0.5;
      const n2 = (Math.sin(nx * 12 + ny * 6) + Math.cos(nx * 4 - ny * 10)) * 0.25;
      const noise = 0.5 + n1 + n2;

      let type: BiomeType = 'meadow';
      let walkable = true;
      let obstacle: 'tree' | 'rock' | 'flower' | 'bush' | 'none' = 'none';

      // Edge of the world is deep water so player can't walk off
      if (x < 2 || y < 2 || x > MAP_SIZE - 3 || y > MAP_SIZE - 3) {
        type = 'water';
        walkable = false;
      } else if (noise < 0.25) {
        type = 'water';
        walkable = false;
      } else if (noise > 0.65) {
        type = 'forest';
        walkable = true;
        // Obstacle generation (dense trees)
        if (hash2D(x, y) > 0.45) {
          obstacle = 'tree';
          walkable = false;
        } else if (hash2D(y, x) > 0.75) {
          obstacle = 'bush';
        }
      } else {
        type = 'meadow';
        // Interspersed grass details & pebbles
        const rand = hash2D(x, y);
        if (rand > 0.95) {
          obstacle = 'rock';
          walkable = false;
        } else if (rand > 0.85) {
          obstacle = 'flower';
        } else if (rand > 0.7) {
          obstacle = 'bush';
        }
      }

      row.push({ x, y, type, walkable, obstacle });
    }
    tiles.push(row);
  }

  // 2. Clear a starting village meadow in the center-ish area (x: 35-45, y: 35-45)
  const centerX = 40;
  const centerY = 40;
  for (let dy = -6; dy <= 6; dy++) {
    for (let dx = -6; dx <= 6; dx++) {
      const tx = centerX + dx;
      const ty = centerY + dy;
      if (tx >= 0 && tx < MAP_SIZE && ty >= 0 && ty < MAP_SIZE) {
        tiles[ty][tx].type = 'meadow';
        tiles[ty][tx].walkable = true;
        tiles[ty][tx].obstacle = 'none';
      }
    }
  }

  // Add village features
  tiles[centerY - 2][centerX - 3].obstacle = 'rock'; // Village well/monument marker
  tiles[centerY - 2][centerX - 3].walkable = false;

  // Set spawn position
  const spawnPosition = { x: centerX, y: centerY };

  // Place a cave entrance in a rocky cluster to the northeast (e.g. x: 65, y: 15)
  const caveX = 62;
  const caveY = 18;
  for (let dy = -3; dy <= 3; dy++) {
    for (let dx = -3; dx <= 3; dx++) {
      const tx = caveX + dx;
      const ty = caveY + dy;
      if (tx >= 0 && tx < MAP_SIZE && ty >= 0 && ty < MAP_SIZE) {
        if (Math.abs(dx) === 2 || Math.abs(dy) === 2) {
          tiles[ty][tx].obstacle = 'rock';
          tiles[ty][tx].walkable = false;
        } else {
          tiles[ty][tx].type = 'meadow';
          tiles[ty][tx].obstacle = 'none';
          tiles[ty][tx].walkable = true;
        }
      }
    }
  }
  tiles[caveY][caveX].type = 'stairs_down'; // Cave entry
  tiles[caveY][caveX].walkable = true;
  tiles[caveY][caveX].obstacle = 'none';

  // 3. Place friendly NPCs in the village and near cave entry
  npcs.push({
    id: 'elder',
    name: 'Elder Aaron',
    x: centerX + 2,
    y: centerY - 1,
    color: '#8b5cf6', // Indigo
    spriteIndex: 0,
    dialogue: [
      {
        id: 'start',
        text: 'Greetings, young traveler! Welcome to Meadowvale. Monsters have emerged in the forests and deep cave to our Northeast. Could you help us?',
        options: [
          { text: 'I am ready to help. What do you need?', nextId: 'quest_explain' },
          { text: 'Just exploring for now.', nextId: 'bye' }
        ]
      },
      {
        id: 'quest_explain',
        text: 'Two troubles haunt us: Slimes gather in the Forest, and Goblins infest the Cave depths. If you slay 4 Forest Slimes or clear out a Cave Goblin, I will reward you handsomely with gold and XP.',
        options: [
          { text: 'I will deal with the Forest Slimes first!', action: 'accept_slime_quest' },
          { text: 'I will descend into the Cave for the Goblin!', action: 'accept_goblin_quest' },
          { text: 'Too scary for me. Farewell.' }
        ]
      },
      {
        id: 'active_quest',
        text: 'How is your quest progressing? Check your quest tracker on the left of your ASUS Vivobook HUD! Eat berries/potions if your health drops low.',
        options: [
          { text: 'Thank you for the advice, Elder!' }
        ]
      },
      {
        id: 'complete_quest',
        text: 'Marvelous deeds! The air feels lighter already. Here is your reward, true hero!',
        options: [
          { text: 'Hooray!', action: 'complete_quest_reward' }
        ]
      },
      {
        id: 'bye',
        text: 'Be safe. Use WASD / Arrow keys to walk, and SPACEBAR or click/tap nearby enemies to swing your sword!',
        options: [{ text: 'Goodbye!' }]
      }
    ]
  });

  npcs.push({
    id: 'merchant',
    name: 'Shopkeeper Lily',
    x: centerX - 3,
    y: centerY + 2,
    color: '#fbbf24', // Amber
    spriteIndex: 1,
    dialogue: [
      {
        id: 'start',
        text: 'Welcome! Survival in of the wilderness requires gear. I have restorative Red Potions and a sturdy Broadsword. Would you like to trade?',
        options: [
          { text: 'Buy Red Potion (+30 HP) [10 gold]', action: 'buy_potion_10' },
          { text: 'Buy Steel Greatsword (+8 Attack) [40 gold]', action: 'buy_sword_40' },
          { text: 'Show me my Gold status', nextId: 'check_gold' },
          { text: 'No, thank you!' }
        ]
      },
      {
        id: 'bought',
        text: 'Pleasure doing business! Items are equipped or loaded into your bag immediately.',
        options: [{ text: 'Great, thanks!', nextId: 'start' }]
      },
      {
        id: 'poor',
        text: 'Oh, you don\'t have enough gold! Slay some Slimes or Wolves first, or complete quests for the Elder.',
        options: [{ text: 'I see.', nextId: 'start' }]
      },
      {
        id: 'check_gold',
        text: 'You look like you have plenty of potential. Defeat monsters nearby to hoard shiny coins!',
        options: [{ text: 'Back to shop', nextId: 'start' }]
      }
    ]
  });

  npcs.push({
    id: 'explorer',
    name: 'Explorer Guy',
    x: caveX - 2,
    y: caveY + 1,
    color: '#06b6d4', // Cyan
    spriteIndex: 2,
    dialogue: [
      {
        id: 'start',
        text: 'Hold on there! Steps ahead lead straight down into the ancient caves. It\'s dark and crawling with dangerous skeletons and heavy rock monsters. Are you armed?',
        options: [
          { text: 'Yes, I am prepared.', nextId: 'advice' },
          { text: 'What is down there?', nextId: 'cave_lore' },
          { text: 'Thanks for the warning!' }
        ]
      },
      {
        id: 'advice',
        text: 'Wonderful! Watch your step. If you find blue glowing mushrooms or glowing red crystal clusters inside the cave, step on them to restore your Mana or Health! Chests inside contain master loot.',
        options: [{ text: 'Good to know!' }]
      },
      {
        id: 'cave_lore',
        text: 'The cave was once a glittering gold mine. Now, Shadow Goblins and stone Golems guard the deep chest. If you survive, you\'ll find artifacts worth a fortune!',
        options: [{ text: 'Sounds awesome!', nextId: 'start' }]
      }
    ]
  });

  // 4. Spawn Overworld Monsters (Forests & outer Meadows)
  for (let i = 0; i < 35; i++) {
    // Slimes spawn in Meadows/Forests primarily
    let mx = Math.floor(Math.random() * (MAP_SIZE - 6)) + 3;
    let my = Math.floor(Math.random() * (MAP_SIZE - 6)) + 3;

    // Direct distance from spawn village (avoid spawning right on top)
    const dist = Math.hypot(mx - centerX, my - centerY);
    const tile = tiles[my][mx];

    if (dist > 10 && tile.walkable && tile.type !== 'water') {
      const isForest = tile.type === 'forest';
      
      const mType = Math.random() > (isForest ? 0.3 : 0.8) ? 'wolf' : 'slime';
      const mName = mType === 'wolf' ? 'Wild Wolf' : 'Meadow Slime';
      const mColor = mType === 'wolf' ? '#94a3b8' : '#34d399';
      const mSize = mType === 'wolf' ? 14 : 10;
      const hpVal = mType === 'wolf' ? 30 : 15;
      const attVal = mType === 'wolf' ? 4 : 2;

      monsters.push({
        id: `monster_overworld_${i}`,
        name: mName,
        type: mType === 'wolf' ? 'wolf' : 'slime',
        x: mx,
        y: my,
        hp: hpVal,
        maxHp: hpVal,
        attack: attVal,
        speed: mType === 'wolf' ? 2 : 1,
        xpReward: mType === 'wolf' ? 25 : 10,
        goldReward: mType === 'wolf' ? 12 : 5,
        color: mColor,
        size: mSize,
        isAggressive: mType === 'wolf',
        state: 'idle',
        startX: mx,
        startY: my,
        lastAttackTime: 0
      });
    }
  }

  return { tiles, spawnPosition, npcs, monsters };
}

export function generateCaves(): {
  tiles: Tile[][];
  spawnPosition: Position;
  monsters: Monster[];
} {
  const tiles: Tile[][] = [];
  const monsters: Monster[] = [];

  // Initialize with perfect solid rock walls
  for (let y = 0; y < CAVE_SIZE; y++) {
    const row: Tile[] = [];
    for (let x = 0; x < CAVE_SIZE; x++) {
      row.push({
        x,
        y,
        type: 'wall',
        walkable: false,
        obstacle: 'rock'
      });
    }
    tiles.push(row);
  }

  // Generate rooms and corridor carving
  interface Room {
    x: number;
    y: number;
    w: number;
    h: number;
  }

  const rooms: Room[] = [];
  const minSize = 6;
  const maxSize = 12;
  const roomCount = 8;

  for (let r = 0; r < roomCount; r++) {
    const w = Math.floor(Math.random() * (maxSize - minSize)) + minSize;
    const h = Math.floor(Math.random() * (maxSize - minSize)) + minSize;
    const x = Math.floor(Math.random() * (CAVE_SIZE - w - 4)) + 2;
    const y = Math.floor(Math.random() * (CAVE_SIZE - h - 4)) + 2;

    // Check overlap with existing rooms
    let overlap = false;
    for (const other of rooms) {
      if (
        x < other.x + other.w &&
        x + w > other.x &&
        y < other.y + other.h &&
        y + h > other.y
      ) {
        overlap = true;
        break;
      }
    }

    if (!overlap) {
      rooms.push({ x, y, w, h });
    }
  }

  // Carve room tiles
  rooms.forEach((room) => {
    for (let cy = room.y; cy < room.y + room.h; cy++) {
      for (let cx = room.x; cx < room.x + room.w; cx++) {
        tiles[cy][cx].type = 'cave';
        tiles[cy][cx].walkable = true;
        tiles[cy][cx].obstacle = 'none';
      }
    }
  });

  // Connect rooms by corridors
  for (let i = 0; i < rooms.length - 1; i++) {
    const r1 = rooms[i];
    const r2 = rooms[i + 1];

    const cx1 = Math.floor(r1.x + r1.w / 2);
    const cy1 = Math.floor(r1.y + r1.h / 2);
    const cx2 = Math.floor(r2.x + r2.w / 2);
    const cy2 = Math.floor(r2.y + r2.h / 2);

    // Horizontal tunnel
    for (let cx = Math.min(cx1, cx2); cx <= Math.max(cx1, cx2); cx++) {
      tiles[cy1][cx].type = 'cave';
      tiles[cy1][cx].walkable = true;
      tiles[cy1][cx].obstacle = 'none';
    }

    // Vertical tunnel
    for (let cy = Math.min(cy1, cy2); cy <= Math.max(cy1, cy2); cy++) {
      tiles[cy][cx2].type = 'cave';
      tiles[cy][cx2].walkable = true;
      tiles[cy][cx2].obstacle = 'none';
    }
  }

  // Confirm we have at least 2 active rooms
  if (rooms.length < 2) {
    // Fallback: carve a simple cross-corridor
    for (let i = 5; i < CAVE_SIZE - 5; i++) {
      tiles[25][i].type = 'cave';
      tiles[25][i].walkable = true;
      tiles[25][i].obstacle = 'none';
      tiles[i][25].type = 'cave';
      tiles[i][25].walkable = true;
      tiles[i][25].obstacle = 'none';
    }
  }

  const firstRoom = rooms[0] || { x: 5, y: 5, w: 4, h: 4 };
  const lastRoom = rooms[rooms.length - 1] || { x: CAVE_SIZE - 10, y: CAVE_SIZE - 10, w: 5, h: 5 };

  // Stairs UP set in first carved room
  const spawnX = Math.floor(firstRoom.x + 1);
  const spawnY = Math.floor(firstRoom.y + 1);
  tiles[spawnY][spawnX].type = 'stairs_up';
  tiles[spawnY][spawnX].walkable = true;
  tiles[spawnY][spawnX].obstacle = 'none';

  // Chest set in last carved room
  const chestX = Math.floor(lastRoom.x + lastRoom.w - 2);
  const chestY = Math.floor(lastRoom.y + lastRoom.h - 2);
  tiles[chestY][chestX].type = 'chest';
  tiles[chestY][chestX].walkable = true;
  tiles[chestY][chestX].obstacle = 'none';

  const spawnPosition = { x: spawnX, y: spawnY };

  // Scatter dynamic cave pickups (Glowing health rocks / crystals, Blue mana mushrooms)
  rooms.forEach((room, roomIdx) => {
    // Add glowing environment pickups to room floors
    if (roomIdx > 0) {
      const px = Math.floor(room.x + Math.random() * (room.w - 2)) + 1;
      const py = Math.floor(room.y + Math.random() * (room.h - 2)) + 1;
      if (tiles[py][px].type === 'cave') {
        tiles[py][px].obstacle = Math.random() > 0.5 ? 'flower' : 'rock'; // repurposed as Magic Shroom / Crystal
      }
    }

    // Spawn Cave Monsters (Skeletons & Goblins & Golems)
    if (roomIdx > 0) {
      const monsterCount = Math.floor(Math.random() * 2) + 1; // 1-2 per room
      for (let m = 0; m < monsterCount; m++) {
        const mx = Math.floor(room.x + Math.random() * (room.w - 2)) + 1;
        const my = Math.floor(room.y + Math.random() * (room.h - 2)) + 1;

        if (tiles[my][mx].type === 'cave' && (mx !== spawnX || my !== spawnY)) {
          const randType = Math.random();
          let mType: 'skeleton' | 'goblin' | 'golem' = 'skeleton';
          let mName = 'Caveland Skeleton';
          let mColor = '#e2e8f0'; // Off-white bones
          let hpVal = 35;
          let attVal = 4;
          let xpVal = 20;
          let speedVal = 1;

          if (randType > 0.75) {
            mType = 'golem';
            mName = 'Prismatic Golem';
            mColor = '#f43f5e'; // Heavy red/pink crystal
            hpVal = 80;
            attVal = 8;
            xpVal = 50;
            speedVal = 0.5; // slow bulky tank
          } else if (randType > 0.4) {
            mType = 'goblin';
            mName = 'Shadow Goblin';
            mColor = '#ef4444'; // Red goblin
            hpVal = 25;
            attVal = 6;
            xpVal = 25;
            speedVal = 2; // nimble backstabber
          }

          monsters.push({
            id: `monster_cave_${roomIdx}_${m}`,
            name: mName,
            type: mType,
            x: mx,
            y: my,
            hp: hpVal,
            maxHp: hpVal,
            attack: attVal,
            speed: speedVal,
            xpReward: xpVal,
            goldReward: hpVal / 2,
            color: mColor,
            size: mType === 'golem' ? 18 : 13,
            isAggressive: true,
            state: 'idle',
            startX: mx,
            startY: my,
            lastAttackTime: 0
          });
        }
      }
    }
  });

  return { tiles, spawnPosition, monsters };
}
