/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BiomeType = 'meadow' | 'forest' | 'cave' | 'water' | 'wall' | 'stairs_up' | 'stairs_down' | 'chest';

export interface Position {
  x: number;
  y: number;
}

export interface PlayerStats {
  hp: number;
  maxHp: number;
  mp: number;
  maxMp: number;
  level: number;
  xp: number;
  maxXp: number;
  gold: number;
  attack: number;
  speed: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  type: 'weapon' | 'potion' | 'armor' | 'material';
  description: string;
  value?: number;
  quantity: number;
  spriteUrl?: string;
  color?: string;
}

export interface DialogueNode {
  id: string;
  text: string;
  options: DialogueOption[];
}

export interface DialogueOption {
  text: string;
  nextId?: string;
  action?: string;
}

export interface NPC {
  id: string;
  name: string;
  x: number;
  y: number;
  color: string;
  dialogue: DialogueNode[];
  activeQuestId?: string;
  spriteIndex: number;
  isCompleted?: boolean;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  status: 'available' | 'active' | 'completed';
  type: 'kill' | 'gather' | 'talk';
  targetId: string; // monster type or NPC name or item name
  requiredCount: number;
  currentCount: number;
  xpReward: number;
  goldReward: number;
}

export interface Monster {
  id: string;
  name: string;
  type: 'slime' | 'skeleton' | 'wolf' | 'goblin' | 'golem';
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  attack: number;
  speed: number;
  xpReward: number;
  goldReward: number;
  color: string;
  size: number;
  isAggressive: boolean;
  state: 'idle' | 'chasing' | 'returning';
  startX: number;
  startY: number;
  lastAttackTime: number;
}

export interface Tile {
  x: number;
  y: number;
  type: BiomeType;
  walkable: boolean;
  revealed?: boolean;
  obstacle?: 'tree' | 'rock' | 'flower' | 'bush' | 'none';
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
  decay: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
}
